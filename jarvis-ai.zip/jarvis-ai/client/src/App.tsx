import { AnimatePresence, motion } from 'framer-motion';
import { useEffect } from 'react';
import { BootScreen } from './components/BootScreen';
import { ChatPanel } from './components/ChatPanel';
import { CommandCenter } from './components/CommandCenter';
import { Header, TitleBlock } from './components/Header';
import { HistoryPanel } from './components/HistoryPanel';
import { Particles } from './components/Particles';
import { ModeLabel, Reactor } from './components/Reactor';
import { SettingsPanel } from './components/SettingsPanel';
import { StatusPanel } from './components/StatusPanel';
import { StatusRail } from './components/StatusRail';
import { Toast } from './components/Toast';
import { VoicePanel } from './components/VoicePanel';
import { Waveform } from './components/Waveform';
import { useT } from './lib/hooks';
import { useStore } from './store';
import type { PanelId } from './types';

function renderPanel(panel: PanelId) {
  switch (panel) {
    case 'chat':
      return <ChatPanel />;
    case 'voice':
      return <VoicePanel />;
    case 'status':
      return <StatusPanel />;
    case 'settings':
      return <SettingsPanel />;
    case 'history':
      return <HistoryPanel />;
  }
}

function PanelHost() {
  const panel = useStore((s) => s.panel);
  return (
    <AnimatePresence mode="wait" initial={false}>
      <motion.div
        key={panel}
        className="h-full"
        initial={{ opacity: 0, y: 14, scale: 0.985 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: -8, scale: 0.99 }}
        transition={{ duration: 0.2, ease: 'easeOut' }}
      >
        {renderPanel(panel)}
      </motion.div>
    </AnimatePresence>
  );
}

/** Centre stage: title, reactor, mode caption, waveform and (tablet/desktop) command center. */
function CenterStage() {
  const t = useT();
  const mode = useStore((s) => s.mode);
  const busy = useStore((s) => s.busy);
  const handsFree = useStore((s) => s.handsFree);
  const dictate = useStore((s) => s.dictate);
  const stopAll = useStore((s) => s.stopAll);
  const setPanel = useStore((s) => s.setPanel);

  const onReactor = () => {
    if (mode === 'speaking' || handsFree) {
      stopAll();
      return;
    }
    if (busy) return;
    setPanel('chat');
    void dictate();
  };

  return (
    <div className="flex h-full min-h-0 w-full flex-col items-center justify-center gap-2 overflow-y-auto overflow-x-hidden py-1 md:gap-3">
      <TitleBlock />
      <div className="w-[min(100%,24dvh)] shrink-0 md:w-[min(100%,40dvh)] lg:w-[min(100%,46dvh)]">
        <Reactor onClick={onReactor} label={t('voiceTapReactor')} />
      </div>
      <ModeLabel />
      <div className="hidden h-12 w-full max-w-md md:block lg:h-14">
        <Waveform mode={mode} />
      </div>
      <div className="hidden md:block">
        <CommandCenter variant="ring" />
      </div>
    </div>
  );
}

export default function App() {
  const mode = useStore((s) => s.mode);
  const booted = useStore((s) => s.booted);
  const lang = useStore((s) => s.settings.lang);
  const refreshHealth = useStore((s) => s.refreshHealth);
  const initVoices = useStore((s) => s.initVoices);
  const stopAll = useStore((s) => s.stopAll);
  const passcode = useStore((s) => s.settings.passcode);

  useEffect(() => {
    document.documentElement.lang = lang;
  }, [lang]);

  useEffect(() => {
    void initVoices();
  }, [initVoices]);

  // Poll the backend so the status indicators stay live.
  useEffect(() => {
    void refreshHealth();
    const id = setInterval(() => void refreshHealth(), 30_000);
    return () => clearInterval(id);
  }, [refreshHealth, passcode]);

  // Escape silences J.A.R.V.I.S and stops the microphone.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') stopAll();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [stopAll]);

  return (
    <div data-mode={mode} className="relative h-[100dvh] w-full overflow-hidden bg-black text-jarvis-100">
      <div className="hud-grid absolute inset-0" />
      <Particles mode={mode} />
      <div className="scan-overlay absolute inset-0" />
      <div className="scan-bar" />
      <div className="vignette absolute inset-0" />

      <div className="relative z-10 flex h-full flex-col">
        <Header />
        <main className="grid min-h-0 flex-1 grid-cols-1 grid-rows-[auto_minmax(0,1fr)] gap-3 px-3 pb-2 sm:px-5 md:grid-cols-[minmax(0,1fr)_minmax(340px,400px)] md:grid-rows-1 lg:grid-cols-[250px_minmax(0,1fr)_minmax(380px,440px)] xl:grid-cols-[280px_minmax(0,1fr)_480px]">
          <aside className="hidden min-h-0 overflow-y-auto lg:block">
            <StatusRail />
          </aside>
          <section className="min-h-0">
            <CenterStage />
          </section>
          <section className="min-h-0 pb-1">
            <PanelHost />
          </section>
        </main>
        <div className="md:hidden">
          <CommandCenter variant="dock" />
        </div>
      </div>

      <Toast />
      <AnimatePresence>{!booted && <BootScreen key="boot" />}</AnimatePresence>
    </div>
  );
}
