import { useEffect, useReducer } from 'react';

interface BeforeInstallPromptEvent extends Event {
  prompt(): Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

let deferred: BeforeInstallPromptEvent | null = null;
const listeners = new Set<() => void>();

if (typeof window !== 'undefined') {
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferred = e as BeforeInstallPromptEvent;
    listeners.forEach((l) => l());
  });
  window.addEventListener('appinstalled', () => {
    deferred = null;
    listeners.forEach((l) => l());
  });
}

export function isStandalone(): boolean {
  if (typeof window === 'undefined') return false;
  const nav = navigator as Navigator & { standalone?: boolean };
  return window.matchMedia('(display-mode: standalone)').matches || nav.standalone === true;
}

export function isIOS(): boolean {
  return /iphone|ipad|ipod/i.test(navigator.userAgent);
}

export interface InstallState {
  /** The browser offered a one-tap install prompt. */
  available: boolean;
  standalone: boolean;
  ios: boolean;
  install: () => Promise<'accepted' | 'dismissed' | 'unavailable'>;
}

export function useInstall(): InstallState {
  const [, rerender] = useReducer((n: number) => n + 1, 0);
  useEffect(() => {
    const listener = () => rerender();
    listeners.add(listener);
    return () => {
      listeners.delete(listener);
    };
  }, []);

  return {
    available: deferred !== null,
    standalone: isStandalone(),
    ios: isIOS(),
    install: async () => {
      if (!deferred) return 'unavailable';
      await deferred.prompt();
      const choice = await deferred.userChoice;
      deferred = null;
      listeners.forEach((l) => l());
      return choice.outcome;
    },
  };
}
