import type { Lang, PanelId } from '../types';
import { LOCALE, t, type TKey } from './i18n';

export type IntentAction =
  | { type: 'panel'; panel: PanelId }
  | { type: 'lang'; lang: Lang }
  | { type: 'clear' };

export interface IntentResult {
  reply: string;
  action?: IntentAction;
}

const PANEL_WORDS: Record<string, PanelId> = {
  chat: 'chat',
  gumzo: 'chat',
  voice: 'voice',
  sauti: 'voice',
  status: 'status',
  hali: 'status',
  settings: 'settings',
  mipangilio: 'settings',
  history: 'history',
  historia: 'history',
};

const PANEL_LABEL: Record<PanelId, TKey> = {
  chat: 'panelChat',
  voice: 'panelVoice',
  status: 'panelStatus',
  settings: 'panelSettings',
  history: 'panelHistory',
};

const TIME_RE = /^(what('?s| is) the time|what time is it|tell me the time|current time|saa ngapi|ni saa ngapi|nambie saa|muda gani)$/;
const DATE_RE = /^(what('?s| is) (the )?date( today)?|what day is it( today)?|today'?s date|tarehe ya leo|leo ni tarehe gani|leo ni siku gani|nambie tarehe)$/;
const OPEN_RE = /^(open|show|go to|fungua|onyesha)\s+(the\s+)?(chat|gumzo|voice|sauti|status|hali|settings|mipangilio|history|historia)(\s+panel)?$/;
const SW_RE = /^((speak|talk|switch|change)( in| to)? swahili|(speak|talk|switch|change)( in| to)? kiswahili|(ongea|zungumza|badili kwenda|badili kuwa) kiswahili)$/;
const EN_RE = /^((speak|talk|switch|change)( in| to)? english|(ongea|zungumza|badili kwenda|badili kuwa) (kiingereza|english))$/;
const CLEAR_RE = /^((clear|reset)( the)? (chat|conversation)|futa (mazungumzo|gumzo))$/;

/**
 * Handles simple device-side commands instantly, without calling the AI.
 * Returns null when the text should go to the AI model.
 */
export function matchIntent(raw: string, lang: Lang, now: Date = new Date()): IntentResult | null {
  const text = raw
    .toLowerCase()
    .replace(/[?!.,]+/g, '')
    .replace(/\s+/g, ' ')
    .trim();
  if (!text || text.length > 60) return null;

  if (TIME_RE.test(text)) {
    const time = now.toLocaleTimeString(LOCALE[lang], { hour: '2-digit', minute: '2-digit', hour12: false });
    return { reply: t(lang, 'intentTime', { time }) };
  }

  if (DATE_RE.test(text)) {
    const date = now.toLocaleDateString(LOCALE[lang], {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    });
    return { reply: t(lang, 'intentDate', { date }) };
  }

  const open = OPEN_RE.exec(text);
  if (open) {
    const panel = PANEL_WORDS[open[3]];
    if (panel) {
      return {
        reply: t(lang, 'intentOpen', { panel: t(lang, PANEL_LABEL[panel]) }),
        action: { type: 'panel', panel },
      };
    }
  }

  if (SW_RE.test(text)) return { reply: t('sw', 'intentLangSw'), action: { type: 'lang', lang: 'sw' } };
  if (EN_RE.test(text)) return { reply: t('en', 'intentLangEn'), action: { type: 'lang', lang: 'en' } };
  if (CLEAR_RE.test(text)) return { reply: t(lang, 'intentCleared'), action: { type: 'clear' } };

  return null;
}
