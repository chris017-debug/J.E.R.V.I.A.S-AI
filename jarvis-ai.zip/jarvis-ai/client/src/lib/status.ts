import { sttSupported, ttsSupported } from './speech';
import { useOnline, useT } from './hooks';
import { useStore } from '../store';

export type Tone = 'ok' | 'warn' | 'bad' | 'dim';

export interface StatusRowData {
  id: string;
  label: string;
  value: string;
  tone: Tone;
  detail?: string;
}

interface NetworkInfo {
  effectiveType?: string;
  downlink?: number;
}

export function networkInfo(): NetworkInfo {
  const nav = navigator as Navigator & { connection?: NetworkInfo };
  return nav.connection ?? {};
}

/** Live system status rows shared by the side rail and the Status panel. */
export function useSystemRows(): StatusRowData[] {
  const t = useT();
  const health = useStore((s) => s.health);
  const healthError = useStore((s) => s.healthError);
  const voices = useStore((s) => s.voices);
  const online = useOnline();

  const core: StatusRowData = {
    id: 'core',
    label: t('stCore'),
    value: healthError ? t('offline') : health ? t('online') : t('checking'),
    tone: healthError ? 'bad' : health ? 'ok' : 'dim',
    detail: health && !healthError ? `${health.latencyMs} ms` : undefined,
  };

  const ai: StatusRowData = {
    id: 'ai',
    label: t('stAi'),
    value: !health ? t('checking') : health.ai.configured ? t('ready') : t('demo'),
    tone: !health ? 'dim' : health.ai.configured ? 'ok' : 'warn',
    detail: health ? `${health.ai.provider} · ${health.ai.model}` : undefined,
  };

  const db: StatusRowData = {
    id: 'db',
    label: t('stDb'),
    value: !health ? t('checking') : !health.db.enabled ? t('localOnly') : health.db.connected ? t('connected') : t('dbError'),
    tone: !health ? 'dim' : !health.db.enabled ? 'warn' : health.db.connected ? 'ok' : 'bad',
  };

  const micIn: StatusRowData = {
    id: 'mic',
    label: t('stMicIn'),
    value: sttSupported ? t('supported') : t('unsupported'),
    tone: sttSupported ? 'ok' : 'bad',
  };

  const speechOut: StatusRowData = {
    id: 'tts',
    label: t('stSpeechOut'),
    value: ttsSupported ? t('supported') : t('unsupported'),
    tone: ttsSupported ? 'ok' : 'bad',
    detail: ttsSupported ? t('voicesFound', { n: voices.length }) : undefined,
  };

  const net = networkInfo();
  const network: StatusRowData = {
    id: 'net',
    label: t('stNetwork'),
    value: online ? t('online') : t('offline'),
    tone: online ? 'ok' : 'bad',
    detail: net.effectiveType ? net.effectiveType.toUpperCase() : undefined,
  };

  return [core, ai, db, micIn, speechOut, network];
}
