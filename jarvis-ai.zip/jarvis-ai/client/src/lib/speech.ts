/**
 * Thin wrapper around the browser's Web Speech API.
 *  - Speech recognition (speech-to-text): Chrome, Edge, Samsung Internet, Android Chrome.
 *  - Speech synthesis (text-to-speech): all modern browsers.
 */

/* ───────────── Speech recognition ───────────── */

interface RecognitionResult {
  isFinal: boolean;
  0: { transcript: string };
}
interface RecognitionEvent {
  resultIndex: number;
  results: ArrayLike<RecognitionResult>;
}
interface RecognitionLike {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  maxAlternatives: number;
  onresult: ((e: RecognitionEvent) => void) | null;
  onerror: ((e: { error: string }) => void) | null;
  onend: (() => void) | null;
  start(): void;
  stop(): void;
  abort(): void;
}
type RecognitionCtor = new () => RecognitionLike;

function recognitionCtor(): RecognitionCtor | null {
  if (typeof window === 'undefined') return null;
  const w = window as unknown as {
    SpeechRecognition?: RecognitionCtor;
    webkitSpeechRecognition?: RecognitionCtor;
  };
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null;
}

export const sttSupported: boolean = recognitionCtor() !== null;
export const ttsSupported: boolean = typeof window !== 'undefined' && 'speechSynthesis' in window;

export interface ListenOptions {
  lang: string;
  onInterim: (text: string) => void;
  onFinal: (text: string) => void;
  onError: (code: string) => void;
  onEnd: () => void;
}

let current: RecognitionLike | null = null;

export function startListening(opts: ListenOptions): void {
  const Ctor = recognitionCtor();
  if (!Ctor) {
    opts.onError('unsupported');
    opts.onEnd();
    return;
  }
  abortListening();

  const rec = new Ctor();
  rec.lang = opts.lang;
  rec.continuous = false;
  rec.interimResults = true;
  rec.maxAlternatives = 1;

  let finalText = '';
  rec.onresult = (e) => {
    let interim = '';
    for (let i = e.resultIndex; i < e.results.length; i++) {
      const r = e.results[i];
      if (r.isFinal) finalText += r[0].transcript;
      else interim += r[0].transcript;
    }
    if (interim) opts.onInterim(`${finalText}${interim}`.trim());
    if (finalText) opts.onFinal(finalText.trim());
  };
  rec.onerror = (e) => opts.onError(e.error);
  rec.onend = () => {
    if (current === rec) current = null;
    opts.onEnd();
  };

  current = rec;
  try {
    rec.start();
  } catch {
    current = null;
    opts.onError('start-failed');
    opts.onEnd();
  }
}

/** Stop listening but still deliver the words captured so far. */
export function stopListening(): void {
  try {
    current?.stop();
  } catch {
    /* already stopped */
  }
}

/** Stop listening and discard the pending result. */
export function abortListening(): void {
  try {
    current?.abort();
  } catch {
    /* already stopped */
  }
  current = null;
}

/* ───────────── Speech synthesis ───────────── */

let voicesCache: SpeechSynthesisVoice[] = [];
let speakToken = 0;

export function loadVoices(): Promise<SpeechSynthesisVoice[]> {
  if (!ttsSupported) return Promise.resolve([]);
  const now = window.speechSynthesis.getVoices();
  if (now.length > 0) {
    voicesCache = now;
    return Promise.resolve(now);
  }
  return new Promise((resolve) => {
    let finished = false;
    const done = () => {
      if (finished) return;
      finished = true;
      voicesCache = window.speechSynthesis.getVoices();
      resolve(voicesCache);
    };
    window.speechSynthesis.addEventListener('voiceschanged', done, { once: true });
    setTimeout(done, 1500);
  });
}

export function voicesForLang(voices: SpeechSynthesisVoice[], lang: 'en' | 'sw'): SpeechSynthesisVoice[] {
  return voices.filter((v) => v.lang.toLowerCase().replace('_', '-').startsWith(lang));
}

/** Prefers a calm British male voice for English, mirroring the film assistant's feel. */
export function pickVoice(
  voices: SpeechSynthesisVoice[],
  lang: 'en' | 'sw',
  preferredURI?: string,
): SpeechSynthesisVoice | null {
  const list = voicesForLang(voices, lang);
  if (preferredURI) {
    const chosen = list.find((v) => v.voiceURI === preferredURI);
    if (chosen) return chosen;
  }
  if (list.length === 0) return null;
  if (lang === 'en') {
    const british = list.filter((v) => /en[-_]gb/i.test(v.lang));
    const maleName = /(male|daniel|arthur|george|oliver|ryan|thomas|james)/i;
    return (
      british.find((v) => maleName.test(v.name) && !/female/i.test(v.name)) ??
      british[0] ??
      list.find((v) => /google/i.test(v.name)) ??
      list[0]
    );
  }
  return list[0];
}

/** Strips markdown/URLs so the voice does not read symbols aloud. */
export function cleanForSpeech(text: string): string {
  return text
    .replace(/```[\s\S]*?```/g, ' ')
    .replace(/`([^`]*)`/g, '$1')
    .replace(/!\[[^\]]*\]\([^)]*\)/g, ' ')
    .replace(/\[([^\]]*)\]\([^)]*\)/g, '$1')
    .replace(/https?:\/\/\S+/g, ' ')
    .replace(/^#{1,6}\s*/gm, '')
    .replace(/^\s*[-*•]\s+/gm, '')
    .replace(/[*_~>|#]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

/** Chrome silently stops long utterances, so speak in sentence-sized chunks. */
function splitChunks(text: string, max = 180): string[] {
  const parts = text.match(/[^.!?;:]+[.!?;:]*\s*/g) ?? [text];
  const out: string[] = [];
  let cur = '';
  for (const p of parts) {
    if (cur && (cur + p).length > max) {
      out.push(cur.trim());
      cur = p;
    } else {
      cur += p;
    }
  }
  if (cur.trim()) out.push(cur.trim());
  return out.flatMap((c) => (c.length > max * 1.5 ? c.match(new RegExp(`.{1,${max}}(\\s|$)`, 'g')) ?? [c] : [c]));
}

export interface SpeakOptions {
  lang: 'en' | 'sw';
  rate: number;
  pitch: number;
  voiceURI: string;
  onStart?: () => void;
}

/** Speaks the text. The promise resolves when speech ends or is interrupted. */
export function speak(text: string, opts: SpeakOptions): Promise<void> {
  return new Promise((resolve) => {
    if (!ttsSupported) {
      resolve();
      return;
    }
    const clean = cleanForSpeech(text);
    if (!clean) {
      resolve();
      return;
    }

    const synth = window.speechSynthesis;
    const token = ++speakToken;
    synth.cancel();

    const chunks = splitChunks(clean);
    const voice = pickVoice(voicesCache.length ? voicesCache : synth.getVoices(), opts.lang, opts.voiceURI);
    let index = 0;

    const next = () => {
      if (token !== speakToken || index >= chunks.length) {
        resolve();
        return;
      }
      const u = new SpeechSynthesisUtterance(chunks[index]);
      u.lang = voice?.lang ?? (opts.lang === 'sw' ? 'sw-KE' : 'en-GB');
      if (voice) u.voice = voice;
      u.rate = opts.rate;
      u.pitch = opts.pitch;
      if (index === 0) u.onstart = () => opts.onStart?.();
      index += 1;
      u.onend = next;
      u.onerror = () => resolve();
      synth.speak(u);
    };

    // A short delay after cancel() avoids Chrome dropping the first utterance.
    setTimeout(next, 60);
  });
}

export function stopSpeaking(): void {
  speakToken += 1;
  if (ttsSupported) window.speechSynthesis.cancel();
}
