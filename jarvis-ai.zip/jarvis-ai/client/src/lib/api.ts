import type { Health, Lang } from '../types';

const BASE = (import.meta.env.VITE_API_URL ?? '').replace(/\/+$/, '');

export class ApiError extends Error {
  readonly code: string;
  readonly status: number;
  constructor(code: string, message: string, status = 0) {
    super(message);
    this.name = 'ApiError';
    this.code = code;
    this.status = status;
  }
}

export interface ApiContext {
  deviceId: string;
  passcode: string;
  lang: Lang;
}

async function request<T>(
  method: 'GET' | 'POST' | 'DELETE',
  path: string,
  ctx: ApiContext,
  body?: unknown,
  timeoutMs = 45_000,
): Promise<T> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  const headers: Record<string, string> = { 'x-device-id': ctx.deviceId, 'x-lang': ctx.lang };
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  if (ctx.passcode) headers['x-jarvis-passcode'] = ctx.passcode;

  let res: Response;
  try {
    res = await fetch(`${BASE}${path}`, {
      method,
      headers,
      body: body !== undefined ? JSON.stringify(body) : undefined,
      signal: controller.signal,
    });
  } catch (err) {
    const aborted = err instanceof DOMException && err.name === 'AbortError';
    throw new ApiError(aborted ? 'timeout' : 'network', '');
  } finally {
    clearTimeout(timer);
  }

  let data: unknown = null;
  try {
    data = await res.json();
  } catch {
    /* response was not JSON */
  }

  if (!res.ok) {
    const err = (data as { error?: { code?: string; message?: string } } | null)?.error;
    if (err) throw new ApiError(err.code ?? 'internal', err.message ?? '', res.status);
    // A dev-server proxy answers 5xx with plain text when the backend is down.
    throw new ApiError(res.status >= 500 ? 'network' : 'internal', '', res.status);
  }
  return data as T;
}

export interface ChatPayload {
  messages: Array<{ role: 'user' | 'assistant'; content: string }>;
  lang: Lang;
  conversationId: string;
  title: string;
}

export interface ChatResult {
  reply: string;
  model: string;
  demo: boolean;
}

export const api = {
  chat: (ctx: ApiContext, payload: ChatPayload) => request<ChatResult>('POST', '/api/chat', ctx, payload),

  async health(ctx: ApiContext): Promise<Health> {
    const t0 = performance.now();
    const data = await request<Omit<Health, 'latencyMs'>>('GET', '/api/health', ctx, undefined, 8_000);
    return { ...data, latencyMs: Math.round(performance.now() - t0) };
  },

  exportHistory: (ctx: ApiContext) =>
    request<{
      enabled: boolean;
      conversations: Array<{
        id: string;
        title: string;
        createdAt: string;
        updatedAt: string;
        messages: Array<{ role: 'user' | 'assistant'; content: string; createdAt: string }>;
      }>;
    }>('GET', '/api/history/export', ctx),

  deleteConversation: (ctx: ApiContext, id: string) => request<{ ok: true }>('DELETE', `/api/history/${id}`, ctx),

  clearHistory: (ctx: ApiContext) => request<{ ok: true }>('DELETE', '/api/history', ctx),
};
