import type { Lang } from '../types';

/** Frequent Swahili function words; enough to tell Swahili from English in a sentence. */
const SW_WORDS = new Set([
  'na', 'ya', 'wa', 'kwa', 'ni', 'la', 'katika', 'hii', 'huu', 'hiyo', 'huo', 'sana', 'habari',
  'asante', 'karibu', 'mimi', 'wewe', 'yako', 'yangu', 'nini', 'gani', 'ndiyo', 'ndio', 'hapana',
  'tafadhali', 'unaweza', 'naweza', 'sasa', 'leo', 'kuwa', 'kama', 'pia', 'lakini', 'au', 'hapa',
  'huko', 'cha', 'vya', 'za', 'kuhusu', 'jinsi', 'nikusaidie', 'nitakusaidia', 'sawa', 'pole',
  'rafiki', 'wako', 'wetu', 'yetu', 'mimi', 'tunaweza', 'ninaweza', 'kitu', 'mambo', 'vipi', 'nzuri',
  'kila', 'bado', 'tayari', 'kwenye', 'sisi', 'wao', 'yake', 'chake', 'kutoka', 'hadi', 'ili',
]);

/**
 * Guess whether a piece of text is Swahili or English. Falls back to `fallback`
 * (the user's interface language) when the text is too short or ambiguous.
 */
export function detectLang(text: string, fallback: Lang): Lang {
  const words = text.toLowerCase().match(/[a-z']+/g) ?? [];
  if (words.length < 3) return fallback;
  let hits = 0;
  for (const w of words) if (SW_WORDS.has(w)) hits++;
  const ratio = hits / words.length;
  if (hits >= 2 && ratio >= 0.14) return 'sw';
  if (hits === 0 || ratio < 0.06) return 'en';
  return fallback;
}

/** RFC4122 v4 UUID that also works on plain-http pages (crypto.randomUUID needs HTTPS). */
export function uuid(): string {
  const b = new Uint8Array(16);
  crypto.getRandomValues(b);
  b[6] = (b[6] & 0x0f) | 0x40;
  b[8] = (b[8] & 0x3f) | 0x80;
  const h = Array.from(b, (x) => x.toString(16).padStart(2, '0'));
  return `${h.slice(0, 4).join('')}-${h.slice(4, 6).join('')}-${h.slice(6, 8).join('')}-${h.slice(8, 10).join('')}-${h.slice(10).join('')}`;
}
