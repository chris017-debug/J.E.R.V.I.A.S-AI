import { useEffect, useState } from 'react';
import { LOCALE, t, type TKey } from './i18n';
import { useStore } from '../store';

/** Re-renders every `intervalMs` with the current time. */
export function useNow(intervalMs = 1000): Date {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), intervalMs);
    return () => clearInterval(id);
  }, [intervalMs]);
  return now;
}

/** Browser online/offline state. */
export function useOnline(): boolean {
  const [online, setOnline] = useState(() => (typeof navigator === 'undefined' ? true : navigator.onLine));
  useEffect(() => {
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    window.addEventListener('online', on);
    window.addEventListener('offline', off);
    return () => {
      window.removeEventListener('online', on);
      window.removeEventListener('offline', off);
    };
  }, []);
  return online;
}

/** Returns a translate function bound to the user's current language. */
export function useT(): (key: TKey, params?: Record<string, string | number>) => string {
  const lang = useStore((s) => s.settings.lang);
  return (key, params) => t(lang, key, params);
}

export function formatClock(now: Date): string {
  return now.toLocaleTimeString('en-GB', { hour12: false });
}

export function formatDate(now: Date, lang: 'en' | 'sw', long = true): string {
  return now.toLocaleDateString(LOCALE[lang], {
    weekday: long ? 'long' : 'short',
    day: 'numeric',
    month: long ? 'long' : 'short',
    year: 'numeric',
  });
}

export function formatDuration(totalSeconds: number): string {
  const d = Math.floor(totalSeconds / 86400);
  const h = Math.floor((totalSeconds % 86400) / 3600);
  const m = Math.floor((totalSeconds % 3600) / 60);
  const s = Math.floor(totalSeconds % 60);
  if (d > 0) return `${d}d ${h}h`;
  if (h > 0) return `${h}h ${m}m`;
  if (m > 0) return `${m}m ${s}s`;
  return `${s}s`;
}
