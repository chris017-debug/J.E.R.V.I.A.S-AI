import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { api, ApiError, type ApiContext } from './lib/api';
import { t, SPEECH_LANG } from './lib/i18n';
import { matchIntent } from './lib/intents';
import { detectLang, uuid } from './lib/lang';
import {
  abortListening,
  loadVoices,
  speak,
  startListening,
  sttSupported,
  stopListening,
  stopSpeaking,
  ttsSupported,
} from './lib/speech';
import type { Conversation, Health, Lang, Message, Mode, PanelId, Settings } from './types';

const MAX_CONVERSATIONS = 50;
const MAX_MESSAGES = 300;
const DEVICE_ID_RE = /^[A-Za-z0-9_-]{8,64}$/;

export const DEFAULT_SETTINGS: Settings = {
  lang: 'en',
  voiceOutput: true,
  autoSpeak: true,
  autoSend: true,
  rate: 1,
  pitch: 0.95,
  voiceURI: '',
  passcode: '',
};

interface Toast {
  id: number;
  kind: 'error' | 'info';
  text: string;
}

interface Stats {
  requests: number;
  totalLatency: number;
  lastLatency: number | null;
}

interface State {
  /* persisted */
  settings: Settings;
  conversations: Conversation[];
  activeId: string | null;
  deviceId: string;

  /* session only */
  panel: PanelId;
  mode: Mode;
  busy: boolean;
  booted: boolean;
  draft: string;
  interim: string;
  handsFree: boolean;
  lastReply: string;
  lastHeard: string;
  health: Health | null;
  healthError: boolean;
  toast: Toast | null;
  stats: Stats;
  voices: SpeechSynthesisVoice[];

  /* actions */
  setPanel: (panel: PanelId) => void;
  updateSettings: (patch: Partial<Settings>) => void;
  resetSettings: () => void;
  setBooted: () => void;
  setDraft: (draft: string) => void;
  notify: (kind: Toast['kind'], text: string) => void;
  dismissToast: () => void;
  newConversation: (switchPanel?: boolean) => string;
  openConversation: (id: string) => void;
  deleteConversation: (id: string) => Promise<void>;
  clearAllHistory: () => Promise<void>;
  sendMessage: (text: string, opts?: { viaVoice?: boolean }) => Promise<void>;
  retryLast: () => Promise<void>;
  speakText: (text: string) => Promise<void>;
  dictate: () => Promise<void>;
  startHandsFree: () => Promise<void>;
  stopAll: () => void;
  refreshHealth: () => Promise<void>;
  restoreFromCloud: () => Promise<void>;
  setDeviceId: (id: string) => boolean;
  initVoices: () => Promise<void>;
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function errorText(lang: Lang, err: unknown): string {
  if (err instanceof ApiError) {
    if (err.code === 'network') return t(lang, 'errNetwork');
    if (err.code === 'timeout') return t(lang, 'errTimeout');
    if (err.code === 'unauthorized_app') return t(lang, 'errPasscode');
    if (err.message) return err.message;
  }
  return t(lang, 'errGeneric');
}

function micErrorText(lang: Lang, code: string): string | null {
  switch (code) {
    case 'aborted':
      return null;
    case 'not-allowed':
    case 'service-not-allowed':
      return t(lang, 'errMicDenied');
    case 'no-speech':
      return t(lang, 'errMicNoSpeech');
    case 'network':
      return t(lang, 'errMicNetwork');
    case 'unsupported':
      return t(lang, 'errMicUnsupported');
    default:
      return t(lang, 'errMicGeneric');
  }
}

export const useStore = create<State>()(
  persist(
    (set, get) => {
      const ctx = (): ApiContext => ({
        deviceId: get().deviceId,
        passcode: get().settings.passcode,
        lang: get().settings.lang,
      });

      const cloudOn = (): boolean => Boolean(get().health?.db.connected);

      const updateConvo = (id: string, fn: (c: Conversation) => Conversation): void => {
        set((s) => ({
          conversations: s.conversations
            .map((c) => (c.id === id ? fn(c) : c))
            .sort((a, b) => b.updatedAt - a.updatedAt),
        }));
      };

      const appendMessage = (id: string, message: Message): void => {
        updateConvo(id, (c) => ({
          ...c,
          title: c.title || (message.role === 'user' ? message.content.slice(0, 48) : c.title),
          updatedAt: Date.now(),
          messages: [...c.messages, message].slice(-MAX_MESSAGES),
        }));
      };

      /** Opens the microphone once and resolves with the final transcript (or an error code). */
      const listenOnce = (): Promise<{ text: string; error?: string }> =>
        new Promise((resolve) => {
          let finalText = '';
          let error: string | undefined;
          set({ mode: 'listening', interim: '' });
          startListening({
            lang: SPEECH_LANG[get().settings.lang],
            onInterim: (text) => set({ interim: text }),
            onFinal: (text) => {
              finalText = text;
              set({ interim: text });
            },
            onError: (code) => {
              error = code;
            },
            onEnd: () => {
              if (get().mode === 'listening') set({ mode: 'idle' });
              set({ interim: '' });
              resolve({ text: finalText, error });
            },
          });
        });

      return {
        settings: DEFAULT_SETTINGS,
        conversations: [],
        activeId: null,
        deviceId: uuid(),

        panel: 'chat',
        mode: 'idle',
        busy: false,
        booted: false,
        draft: '',
        interim: '',
        handsFree: false,
        lastReply: '',
        lastHeard: '',
        health: null,
        healthError: false,
        toast: null,
        stats: { requests: 0, totalLatency: 0, lastLatency: null },
        voices: [],

        setPanel: (panel) => set({ panel }),

        updateSettings: (patch) => set((s) => ({ settings: { ...s.settings, ...patch } })),

        resetSettings: () =>
          set((s) => ({ settings: { ...DEFAULT_SETTINGS, lang: s.settings.lang, passcode: s.settings.passcode } })),

        setBooted: () => set({ booted: true }),

        setDraft: (draft) => set({ draft }),

        notify: (kind, text) => set({ toast: { id: Date.now(), kind, text } }),

        dismissToast: () => set({ toast: null }),

        newConversation: (switchPanel = true) => {
          const existing = get().conversations.find((c) => c.id === get().activeId);
          if (existing && existing.messages.length === 0) {
            if (switchPanel) set({ panel: 'chat' });
            return existing.id; // reuse the empty one
          }
          const now = Date.now();
          const convo: Conversation = { id: uuid(), title: '', createdAt: now, updatedAt: now, messages: [] };
          set((s) => ({
            conversations: [convo, ...s.conversations].slice(0, MAX_CONVERSATIONS),
            activeId: convo.id,
            ...(switchPanel ? { panel: 'chat' as PanelId } : {}),
          }));
          return convo.id;
        },

        openConversation: (id) => {
          if (get().conversations.some((c) => c.id === id)) set({ activeId: id, panel: 'chat' });
        },

        deleteConversation: async (id) => {
          set((s) => ({
            conversations: s.conversations.filter((c) => c.id !== id),
            activeId: s.activeId === id ? null : s.activeId,
          }));
          if (cloudOn()) {
            try {
              await api.deleteConversation(ctx(), id);
            } catch {
              /* local copy is already gone; cloud cleanup is best-effort */
            }
          }
        },

        clearAllHistory: async () => {
          set({ conversations: [], activeId: null });
          if (cloudOn()) {
            try {
              await api.clearHistory(ctx());
            } catch {
              get().notify('error', errorText(get().settings.lang, new ApiError('network', '')));
            }
          }
        },

        speakText: async (text) => {
          if (!ttsSupported) return;
          const { settings } = get();
          set({ mode: 'speaking' });
          await speak(text, {
            lang: detectLang(text, settings.lang),
            rate: settings.rate,
            pitch: settings.pitch,
            voiceURI: settings.voiceURI,
            onStart: () => set({ mode: 'speaking' }),
          });
          if (get().mode === 'speaking') set({ mode: 'idle' });
        },

        sendMessage: async (raw, opts) => {
          const text = raw.trim();
          if (!text || get().busy) return;
          const lang = get().settings.lang;

          const activeId = get().activeId;
          const convoId =
            activeId && get().conversations.some((c) => c.id === activeId) ? activeId : get().newConversation(false);

          appendMessage(convoId, { id: uuid(), role: 'user', content: text, ts: Date.now() });
          stopSpeaking();
          set({ busy: true, mode: 'thinking', draft: '', interim: '', lastHeard: text });

          let reply = '';
          let isError = false;
          let demo = false;
          let local = false;

          const intent = matchIntent(text, lang);
          if (intent) {
            local = true;
            reply = intent.reply;
            await sleep(450);
            const action = intent.action;
            if (action?.type === 'panel') set({ panel: action.panel });
            if (action?.type === 'lang') set((s) => ({ settings: { ...s.settings, lang: action.lang } }));
            if (action?.type === 'clear') updateConvo(convoId, (c) => ({ ...c, messages: [], title: '' }));
          } else {
            try {
              const convo = get().conversations.find((c) => c.id === convoId);
              const history = (convo?.messages ?? [])
                .filter((m) => m.role !== 'error')
                .slice(-20)
                .map((m) => ({ role: m.role as 'user' | 'assistant', content: m.content }));
              const started = performance.now();
              const res = await api.chat(ctx(), {
                messages: history,
                lang,
                conversationId: convoId,
                title: convo?.title || text.slice(0, 48),
              });
              const latency = Math.round(performance.now() - started);
              set((s) => ({
                stats: {
                  requests: s.stats.requests + 1,
                  totalLatency: s.stats.totalLatency + latency,
                  lastLatency: latency,
                },
              }));
              reply = res.reply;
              demo = res.demo;
            } catch (err) {
              isError = true;
              reply = errorText(lang, err);
            }
          }

          appendMessage(convoId, {
            id: uuid(),
            role: isError ? 'error' : 'assistant',
            content: reply,
            ts: Date.now(),
            demo,
            local,
          });
          set({ busy: false, mode: 'idle', lastReply: isError ? '' : reply });

          const { settings } = get();
          if (!isError && settings.voiceOutput && (opts?.viaVoice || settings.autoSpeak)) {
            await get().speakText(reply);
          }
        },

        retryLast: async () => {
          const convo = get().conversations.find((c) => c.id === get().activeId);
          if (!convo || get().busy) return;
          const msgs = convo.messages;
          // Drop trailing error bubbles and the user message that caused them, then resend it.
          let end = msgs.length;
          while (end > 0 && msgs[end - 1].role === 'error') end--;
          const lastUser = end > 0 && msgs[end - 1].role === 'user' ? msgs[end - 1] : null;
          if (!lastUser) return;
          updateConvo(convo.id, (c) => ({ ...c, messages: c.messages.slice(0, end - 1) }));
          await get().sendMessage(lastUser.content);
        },

        dictate: async () => {
          const s = get();
          if (s.mode === 'listening') {
            stopListening();
            return;
          }
          if (s.busy) return;
          const lang = s.settings.lang;
          if (!sttSupported) {
            get().notify('error', t(lang, 'errMicUnsupported'));
            return;
          }
          stopSpeaking();
          const result = await listenOnce();
          if (result.error) {
            const msg = micErrorText(lang, result.error);
            if (msg) get().notify('error', msg);
            return;
          }
          if (!result.text) return;
          if (get().settings.autoSend) await get().sendMessage(result.text, { viaVoice: true });
          else set({ draft: result.text });
        },

        startHandsFree: async () => {
          if (get().handsFree) return;
          const lang = get().settings.lang;
          if (!sttSupported) {
            get().notify('error', t(lang, 'errMicUnsupported'));
            return;
          }
          set({ handsFree: true });
          let misses = 0;
          let first = true;
          while (get().handsFree) {
            stopSpeaking();
            if (!first) await sleep(350); // let the speaker tail fade so it is not heard as input
            first = false;
            if (!get().handsFree) break;

            const result = await listenOnce();
            if (!get().handsFree) break;

            if (result.error && result.error !== 'no-speech' && result.error !== 'aborted') {
              const msg = micErrorText(get().settings.lang, result.error);
              if (msg) get().notify('error', msg);
              break;
            }
            if (!result.text) {
              misses += 1;
              if (misses >= 3) {
                get().notify('info', t(get().settings.lang, 'voiceIdleStop'));
                break;
              }
              continue;
            }
            misses = 0;
            await get().sendMessage(result.text, { viaVoice: true });
          }
          set({ handsFree: false });
          if (get().mode === 'listening') set({ mode: 'idle' });
        },

        stopAll: () => {
          set({ handsFree: false });
          abortListening();
          stopSpeaking();
          set({ mode: get().busy ? 'thinking' : 'idle', interim: '' });
        },

        refreshHealth: async () => {
          try {
            const health = await api.health(ctx());
            set({ health, healthError: false });
          } catch {
            set({ healthError: true });
          }
        },

        restoreFromCloud: async () => {
          const lang = get().settings.lang;
          try {
            const data = await api.exportHistory(ctx());
            const known = new Set(get().conversations.map((c) => c.id));
            const restored: Conversation[] = data.conversations
              .filter((c) => !known.has(c.id) && c.messages.length > 0)
              .map((c) => ({
                id: c.id,
                title: c.title,
                createdAt: Date.parse(c.createdAt) || Date.now(),
                updatedAt: Date.parse(c.updatedAt) || Date.now(),
                messages: c.messages.map((m) => ({
                  id: uuid(),
                  role: m.role,
                  content: m.content,
                  ts: Date.parse(m.createdAt) || Date.now(),
                })),
              }));
            if (restored.length === 0) {
              get().notify('info', t(lang, 'nothingToRestore'));
              return;
            }
            set((s) => ({
              conversations: [...s.conversations, ...restored]
                .sort((a, b) => b.updatedAt - a.updatedAt)
                .slice(0, MAX_CONVERSATIONS),
            }));
            get().notify('info', t(lang, 'restored', { n: restored.length }));
          } catch (err) {
            get().notify('error', errorText(lang, err));
          }
        },

        setDeviceId: (id) => {
          const clean = id.trim();
          if (!DEVICE_ID_RE.test(clean)) return false;
          set({ deviceId: clean });
          return true;
        },

        initVoices: async () => {
          const voices = await loadVoices();
          set({ voices });
        },
      };
    },
    {
      name: 'jarvis-store-v1',
      version: 1,
      partialize: (s) => ({
        settings: s.settings,
        conversations: s.conversations,
        activeId: s.activeId,
        deviceId: s.deviceId,
      }),
      merge: (persisted, current) => {
        const p = (persisted ?? {}) as Partial<State>;
        return {
          ...current,
          ...p,
          settings: { ...current.settings, ...(p.settings ?? {}) },
        };
      },
    },
  ),
);

export function selectActive(s: State): Conversation | null {
  return s.conversations.find((c) => c.id === s.activeId) ?? null;
}
