import { Check, Copy, Download, Play, RotateCcw, Settings as SettingsIcon, Trash2 } from 'lucide-react';
import { useEffect, useState } from 'react';
import { useT } from '../lib/hooks';
import { useInstall } from '../lib/install';
import { ttsSupported, voicesForLang } from '../lib/speech';
import { useStore } from '../store';
import type { Lang } from '../types';
import { copyText, PanelShell, Section, Toggle } from './ui';

function Slider({
  label,
  value,
  min,
  max,
  step,
  onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  onChange: (v: number) => void;
}) {
  return (
    <label className="block">
      <div className="mb-1 flex justify-between text-sm font-semibold text-jarvis-100/90">
        <span>{label}</span>
        <span className="font-display text-xs text-[var(--accent)] tabular-nums">{value.toFixed(2)}</span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="h-2 w-full cursor-pointer"
        style={{ accentColor: 'var(--accent)' }}
      />
    </label>
  );
}

export function SettingsPanel() {
  const t = useT();
  const settings = useStore((s) => s.settings);
  const deviceId = useStore((s) => s.deviceId);
  const voices = useStore((s) => s.voices);
  const updateSettings = useStore((s) => s.updateSettings);
  const resetSettings = useStore((s) => s.resetSettings);
  const setDeviceId = useStore((s) => s.setDeviceId);
  const clearAllHistory = useStore((s) => s.clearAllHistory);
  const speakText = useStore((s) => s.speakText);
  const notify = useStore((s) => s.notify);
  const install = useInstall();

  const [syncDraft, setSyncDraft] = useState(deviceId);
  useEffect(() => setSyncDraft(deviceId), [deviceId]);

  const langVoices = voicesForLang(voices, settings.lang);

  const langButton = (id: Lang, label: string) => (
    <button
      type="button"
      aria-pressed={settings.lang === id}
      onClick={() => updateSettings({ lang: id, voiceURI: '' })}
      className={`flex-1 rounded-lg border px-3 py-2 font-semibold transition ${
        settings.lang === id
          ? 'border-[var(--accent)] bg-[rgba(var(--accent-rgb),0.28)] text-white shadow-[0_0_14px_rgba(var(--accent-rgb),0.4)]'
          : 'border-[rgba(var(--accent-rgb),0.3)] text-[var(--accent)] hover:bg-[rgba(var(--accent-rgb),0.12)]'
      }`}
    >
      {label}
    </button>
  );

  const onInstall = async () => {
    if (install.available) {
      const result = await install.install();
      if (result === 'accepted') notify('info', t('installedOk'));
      return;
    }
    notify('info', install.ios ? t('installIos') : t('installManual'));
  };

  const onCopy = async () => {
    if (await copyText(deviceId)) notify('info', t('copied'));
  };

  const onApplySync = () => {
    const ok = setDeviceId(syncDraft);
    notify(ok ? 'info' : 'error', ok ? t('syncApplied') : t('syncInvalid'));
  };

  return (
    <PanelShell title={t('panelSettings')} icon={SettingsIcon}>
      <div className="h-full space-y-3 overflow-y-auto p-3">
        <Section title={t('language')}>
          <div className="flex gap-2">
            {langButton('en', t('langEn'))}
            {langButton('sw', t('langSw'))}
          </div>
        </Section>

        <Section title={t('voiceSection')}>
          <Toggle checked={settings.voiceOutput} onChange={(v) => updateSettings({ voiceOutput: v })} label={t('voiceOutput')} disabled={!ttsSupported} />
          <Toggle checked={settings.autoSpeak} onChange={(v) => updateSettings({ autoSpeak: v })} label={t('autoSpeak')} disabled={!ttsSupported || !settings.voiceOutput} />
          <Toggle checked={settings.autoSend} onChange={(v) => updateSettings({ autoSend: v })} label={t('autoSend')} />

          {ttsSupported && (
            <>
              <label className="block">
                <span className="mb-1 block text-sm font-semibold text-jarvis-100/90">{t('voice')}</span>
                <select
                  value={settings.voiceURI}
                  onChange={(e) => updateSettings({ voiceURI: e.target.value })}
                  className="hud-input !py-2"
                >
                  <option value="">{t('voiceAuto')}</option>
                  {langVoices.map((v) => (
                    <option key={v.voiceURI} value={v.voiceURI}>
                      {v.name} ({v.lang})
                    </option>
                  ))}
                </select>
              </label>
              <Slider label={t('rate')} value={settings.rate} min={0.6} max={1.5} step={0.05} onChange={(v) => updateSettings({ rate: v })} />
              <Slider label={t('pitch')} value={settings.pitch} min={0.5} max={1.5} step={0.05} onChange={(v) => updateSettings({ pitch: v })} />
              <button type="button" className="hud-btn w-full" onClick={() => void speakText(t('testPhrase'))}>
                <Play className="h-4 w-4" /> {t('testVoice')}
              </button>
            </>
          )}
        </Section>

        <Section title={t('securitySection')}>
          <label className="block">
            <span className="mb-1 block text-sm font-semibold text-jarvis-100/90">{t('passcode')}</span>
            <input
              type="password"
              autoComplete="off"
              value={settings.passcode}
              onChange={(e) => updateSettings({ passcode: e.target.value })}
              className="hud-input"
              placeholder="••••••••"
            />
            <span className="mt-1 block text-xs text-jarvis-200/55">{t('passcodeHint')}</span>
          </label>

          <label className="block">
            <span className="mb-1 block text-sm font-semibold text-jarvis-100/90">{t('syncCode')}</span>
            <div className="flex gap-2">
              <input
                value={syncDraft}
                onChange={(e) => setSyncDraft(e.target.value)}
                spellCheck={false}
                className="hud-input !px-2 font-mono text-xs"
                aria-label={t('syncCode')}
              />
              <button type="button" className="hud-btn !px-3" onClick={() => void onCopy()} aria-label={t('copy')} title={t('copy')}>
                <Copy className="h-4 w-4" />
              </button>
              <button
                type="button"
                className="hud-btn !px-3"
                onClick={onApplySync}
                disabled={syncDraft === deviceId}
                aria-label={t('apply')}
                title={t('apply')}
              >
                <Check className="h-4 w-4" />
              </button>
            </div>
            <span className="mt-1 block text-xs text-jarvis-200/55">{t('syncHint')}</span>
          </label>
        </Section>

        <Section title={t('appSection')}>
          {install.standalone ? (
            <p className="flex items-center gap-2 text-sm text-[#38ffd7]">
              <Check className="h-4 w-4" /> {t('installedOk')}
            </p>
          ) : (
            <button type="button" className="hud-btn w-full" onClick={() => void onInstall()}>
              <Download className="h-4 w-4" /> {t('installApp')}
            </button>
          )}
          <button
            type="button"
            className="hud-btn w-full"
            onClick={() => {
              resetSettings();
              notify('info', t('resetDone'));
            }}
          >
            <RotateCcw className="h-4 w-4" /> {t('resetSettings')}
          </button>
        </Section>

        <Section title={t('dataSection')}>
          <button
            type="button"
            className="hud-btn danger w-full"
            onClick={() => {
              if (window.confirm(t('confirmClear'))) void clearAllHistory();
            }}
          >
            <Trash2 className="h-4 w-4" /> {t('clearAll')}
          </button>
        </Section>
      </div>
    </PanelShell>
  );
}
