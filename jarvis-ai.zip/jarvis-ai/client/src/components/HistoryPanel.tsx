import { Cloud, CloudDownload, CloudOff, Download, History as HistoryIcon, Plus, Search, Trash2 } from 'lucide-react';
import { useMemo, useState } from 'react';
import { LOCALE } from '../lib/i18n';
import { useT } from '../lib/hooks';
import { useStore } from '../store';
import { IconButton, PanelShell } from './ui';

export function HistoryPanel() {
  const t = useT();
  const lang = useStore((s) => s.settings.lang);
  const conversations = useStore((s) => s.conversations);
  const activeId = useStore((s) => s.activeId);
  const cloud = useStore((s) => Boolean(s.health?.db.connected));
  const openConversation = useStore((s) => s.openConversation);
  const deleteConversation = useStore((s) => s.deleteConversation);
  const newConversation = useStore((s) => s.newConversation);
  const restoreFromCloud = useStore((s) => s.restoreFromCloud);
  const [query, setQuery] = useState('');

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    return conversations
      .filter((c) => c.messages.length > 0 || c.id === activeId)
      .filter((c) => !q || c.title.toLowerCase().includes(q) || c.messages.some((m) => m.content.toLowerCase().includes(q)));
  }, [conversations, query, activeId]);

  const exportJson = () => {
    const blob = new Blob([JSON.stringify(conversations, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `jarvis-history-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };

  const fmt = (ts: number) =>
    new Date(ts).toLocaleString(LOCALE[lang], { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });

  return (
    <PanelShell
      title={t('panelHistory')}
      icon={HistoryIcon}
      actions={
        <>
          {cloud && <IconButton icon={CloudDownload} label={t('restoreCloud')} onClick={() => void restoreFromCloud()} />}
          <IconButton icon={Download} label={t('exportJson')} onClick={exportJson} />
          <IconButton icon={Plus} label={t('newChat')} onClick={() => newConversation()} />
        </>
      }
    >
      <div className="flex h-full min-h-0 flex-col">
        <div className="shrink-0 space-y-2 border-b border-[rgba(var(--accent-rgb),0.2)] p-3">
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[var(--accent)]/70" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={t('search')}
              aria-label={t('search')}
              className="hud-input !pl-9"
            />
          </div>
          <p className={`flex items-center gap-1.5 text-xs ${cloud ? 'text-[#38ffd7]' : 'text-jarvis-200/55'}`}>
            {cloud ? <Cloud className="h-3.5 w-3.5" /> : <CloudOff className="h-3.5 w-3.5" />}
            {cloud ? t('cloudOn') : t('cloudOff')}
          </p>
        </div>

        <div className="min-h-0 flex-1 space-y-2 overflow-y-auto p-3">
          {visible.length === 0 && <p className="py-8 text-center text-sm text-jarvis-200/55">{t('historyEmpty')}</p>}
          {visible.map((c) => (
            <div
              key={c.id}
              className={`flex items-center gap-2 rounded-xl border p-2.5 transition ${
                c.id === activeId
                  ? 'border-[var(--accent)] bg-[rgba(var(--accent-rgb),0.14)]'
                  : 'border-[rgba(var(--accent-rgb),0.2)] bg-black/30 hover:bg-[rgba(var(--accent-rgb),0.08)]'
              }`}
            >
              <button
                type="button"
                onClick={() => openConversation(c.id)}
                className="min-w-0 flex-1 text-left"
                aria-label={`${t('open')}: ${c.title || t('untitled')}`}
              >
                <div className="truncate text-[1rem] font-semibold text-white">{c.title || t('untitled')}</div>
                <div className="text-xs text-jarvis-200/60">
                  {fmt(c.updatedAt)} · {t('msgs', { n: c.messages.length })}
                </div>
              </button>
              <IconButton
                icon={Trash2}
                label={t('delete')}
                danger
                onClick={() => {
                  if (window.confirm(t('confirmDelete'))) void deleteConversation(c.id);
                }}
              />
            </div>
          ))}
        </div>
      </div>
    </PanelShell>
  );
}
