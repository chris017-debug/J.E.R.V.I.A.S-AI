import { motion } from 'framer-motion';
import { Power } from 'lucide-react';
import { useEffect, useState } from 'react';
import { t, type TKey } from '../lib/i18n';
import { useStore } from '../store';
import { LangToggle } from './Header';
import { Reactor } from './Reactor';

const LINES: TKey[] = ['bootLine1', 'bootLine2', 'bootLine3', 'bootLine4', 'bootLine5'];

function greetingKey(hour: number): TKey {
  if (hour >= 5 && hour < 12) return 'greetMorning';
  if (hour >= 12 && hour < 17) return 'greetAfternoon';
  if (hour >= 17 && hour < 22) return 'greetEvening';
  return 'greetNight';
}

/**
 * Start-up sequence. The button press is also the user gesture browsers require
 * before they allow speech synthesis, so J.A.R.V.I.S can greet out loud.
 */
export function BootScreen() {
  const lang = useStore((s) => s.settings.lang);
  const voiceOutput = useStore((s) => s.settings.voiceOutput);
  const setBooted = useStore((s) => s.setBooted);
  const speakText = useStore((s) => s.speakText);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const id = setTimeout(() => setReady(true), 2600);
    return () => clearTimeout(id);
  }, []);

  const start = () => {
    setBooted();
    if (voiceOutput) void speakText(t(lang, greetingKey(new Date().getHours())));
  };

  return (
    <motion.div
      className="absolute inset-0 z-[60] flex flex-col items-center justify-center gap-5 bg-black px-6"
      initial={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <div className="absolute right-4 top-[max(1rem,env(safe-area-inset-top))]">
        <LangToggle />
      </div>

      <div className="w-[min(60vw,34dvh)]">
        <Reactor onClick={() => undefined} label="J.A.R.V.I.S" />
      </div>

      <div className="text-center">
        <h1 className="font-display text-3xl font-bold tracking-[0.3em] text-white glow-text sm:text-4xl">J.A.R.V.I.S</h1>
        <p className="hud-label mt-1 !text-[0.5rem] !tracking-[0.17em] sm:!text-[0.62rem] sm:!tracking-[0.3em]">
          JUST A RATHER VERY INTELLIGENT SYSTEM
        </p>
      </div>

      <div className="w-full max-w-xs space-y-1.5 font-mono text-xs text-jarvis-300">
        {LINES.map((key, i) => (
          <div
            key={key}
            className="flex items-center gap-2"
            style={{ animation: 'boot-line 0.4s both', animationDelay: `${i * 450}ms` }}
          >
            <span className="text-[#38ffd7]">▸</span>
            {t(lang, key)}
          </div>
        ))}
        <div className="mt-2 h-1 overflow-hidden rounded-full bg-jarvis-900">
          <div
            className="h-full origin-left rounded-full bg-[var(--accent)] shadow-[0_0_10px_var(--accent)]"
            style={{ animation: 'boot-fill 2.4s linear forwards' }}
          />
        </div>
      </div>

      <div className="h-14">
        {ready && (
          <motion.button
            type="button"
            onClick={start}
            initial={{ opacity: 0, scale: 0.92 }}
            animate={{ opacity: 1, scale: 1 }}
            className="hud-btn !px-8 !py-3 font-display !text-sm tracking-[0.3em] shadow-glow"
            autoFocus
          >
            <Power className="h-5 w-5" /> {t(lang, 'bootInit')}
          </motion.button>
        )}
      </div>
    </motion.div>
  );
}
