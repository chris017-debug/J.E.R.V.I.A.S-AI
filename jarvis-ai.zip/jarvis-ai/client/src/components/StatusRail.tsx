import type { CSSProperties } from 'react';
import { formatClock, formatDate, useNow, useT } from '../lib/hooks';
import { useSystemRows } from '../lib/status';
import { useStore } from '../store';
import { StatusRow } from './ui';

const EQ = Array.from({ length: 16 }, (_, i) => i);

function Light({ on, label }: { on: boolean; label: string }) {
  return (
    <div className="flex flex-col items-center gap-1.5">
      <span
        className={`h-3 w-3 rounded-full border transition ${
          on
            ? 'border-[var(--accent)] bg-[var(--accent)] shadow-[0_0_14px_var(--accent)]'
            : 'border-jarvis-700 bg-black/40'
        }`}
      />
      <span className="hud-label !text-[0.5rem]">{label}</span>
    </div>
  );
}

/** Left-hand HUD column (desktop): big clock, system status and AI activity. */
export function StatusRail() {
  const t = useT();
  const lang = useStore((s) => s.settings.lang);
  const mode = useStore((s) => s.mode);
  const stats = useStore((s) => s.stats);
  const now = useNow();
  const rows = useSystemRows();

  const avg = stats.requests > 0 ? Math.round(stats.totalLatency / stats.requests) : null;

  return (
    <div className="flex flex-col gap-3">
      <div className="holo-panel p-4 text-center">
        <div className="font-display text-[1.9rem] font-semibold tracking-[0.12em] text-white glow-text tabular-nums xl:text-4xl">
          {formatClock(now)}
        </div>
        <div className="mt-1 text-sm font-semibold uppercase tracking-[0.18em] text-jarvis-200/80">
          {formatDate(now, lang)}
        </div>
      </div>

      <div className="holo-panel p-4">
        <div className="hud-label mb-1">{t('systemStatus')}</div>
        {rows.map((r) => (
          <StatusRow key={r.id} label={r.label} value={r.value} tone={r.tone} detail={r.detail} />
        ))}
      </div>

      <div className="holo-panel p-4">
        <div className="hud-label mb-3">{t('aiActivity')}</div>
        <div className="mb-4 flex justify-around">
          <Light on={mode === 'listening'} label="LISTEN" />
          <Light on={mode === 'thinking'} label="THINK" />
          <Light on={mode === 'speaking'} label="SPEAK" />
        </div>
        <div className="flex h-12 items-end justify-center gap-1" aria-hidden>
          {EQ.map((i) => (
            <span key={i} className="eq-bar" style={{ ['--i' as string]: i } as CSSProperties} />
          ))}
        </div>
        <div className="mt-3 grid grid-cols-2 gap-2 text-center">
          <div>
            <div className="hud-label !text-[0.5rem]">{t('requests')}</div>
            <div className="font-display text-lg text-white tabular-nums">{stats.requests}</div>
          </div>
          <div>
            <div className="hud-label !text-[0.5rem]">{t('avgLatency')}</div>
            <div className="font-display text-lg text-white tabular-nums">{avg === null ? '—' : `${avg} ms`}</div>
          </div>
        </div>
      </div>
    </div>
  );
}
