import { Activity, RefreshCw } from 'lucide-react';
import { useState } from 'react';
import { formatDuration, useT } from '../lib/hooks';
import { networkInfo, useSystemRows } from '../lib/status';
import { useStore } from '../store';
import { PanelShell, Stat, StatusRow } from './ui';

export function StatusPanel() {
  const t = useT();
  const rows = useSystemRows();
  const health = useStore((s) => s.health);
  const stats = useStore((s) => s.stats);
  const conversations = useStore((s) => s.conversations);
  const refreshHealth = useStore((s) => s.refreshHealth);
  const initVoices = useStore((s) => s.initVoices);
  const notify = useStore((s) => s.notify);
  const [running, setRunning] = useState(false);

  const totalMessages = conversations.reduce((sum, c) => sum + c.messages.length, 0);
  const avg = stats.requests > 0 ? `${Math.round(stats.totalLatency / stats.requests)} ms` : '—';
  const nav = navigator as Navigator & { deviceMemory?: number };
  const net = networkInfo();

  const runDiagnostics = async () => {
    setRunning(true);
    await Promise.all([refreshHealth(), initVoices(), new Promise((r) => setTimeout(r, 900))]);
    setRunning(false);
    const failed = useStore.getState().healthError;
    notify(failed ? 'error' : 'info', failed ? t('diagFail') : t('diagDone'));
  };

  return (
    <PanelShell title={t('panelStatus')} icon={Activity}>
      <div className="h-full space-y-3 overflow-y-auto p-3">
        <div className="rounded-xl border border-[rgba(var(--accent-rgb),0.18)] bg-black/25 px-3 py-1">
          {rows.map((r) => (
            <StatusRow key={r.id} label={r.label} value={r.value} tone={r.tone} detail={r.detail} />
          ))}
        </div>

        <div className="grid grid-cols-2 gap-2">
          <Stat label={t('latency')} value={health ? `${health.latencyMs} ms` : '—'} />
          <Stat label={t('uptime')} value={health ? formatDuration(health.uptimeSec) : '—'} />
          <Stat label={t('requests')} value={String(stats.requests)} />
          <Stat label={t('avgLatency')} value={avg} />
          <Stat label={t('messages')} value={String(totalMessages)} />
          <Stat label={t('threads')} value={String(navigator.hardwareConcurrency || '—')} />
          {nav.deviceMemory !== undefined && <Stat label="RAM" value={`≥ ${nav.deviceMemory} GB`} />}
          {net.downlink !== undefined && <Stat label="↓ Mbps" value={String(net.downlink)} />}
        </div>

        <button type="button" onClick={() => void runDiagnostics()} disabled={running} className="hud-btn w-full">
          <RefreshCw className={`h-4 w-4 ${running ? 'animate-spin' : ''}`} />
          {running ? t('diagRunning') : t('diagnostics')}
        </button>
      </div>
    </PanelShell>
  );
}
