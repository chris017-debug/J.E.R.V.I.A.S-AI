import { Activity, History as HistoryIcon, MessageSquare, Mic, Settings as SettingsIcon, type LucideIcon } from 'lucide-react';
import { useT } from '../lib/hooks';
import type { TKey } from '../lib/i18n';
import { useStore } from '../store';
import type { PanelId } from '../types';

const ITEMS: Array<{ id: PanelId; icon: LucideIcon; label: TKey }> = [
  { id: 'chat', icon: MessageSquare, label: 'navChat' },
  { id: 'voice', icon: Mic, label: 'navVoice' },
  { id: 'status', icon: Activity, label: 'navStatus' },
  { id: 'settings', icon: SettingsIcon, label: 'navSettings' },
  { id: 'history', icon: HistoryIcon, label: 'navHistory' },
];

/** The command center: Chat, Voice Assistant, System Status, Settings and History. */
export function CommandCenter({ variant }: { variant: 'dock' | 'ring' }) {
  const t = useT();
  const panel = useStore((s) => s.panel);
  const setPanel = useStore((s) => s.setPanel);

  if (variant === 'dock') {
    return (
      <nav
        aria-label="Command center"
        className="safe-bottom relative z-20 grid shrink-0 grid-cols-5 gap-1 border-t border-[rgba(var(--accent-rgb),0.3)] bg-black/80 px-2 pt-1.5 backdrop-blur-md"
      >
        {ITEMS.map(({ id, icon: Icon, label }) => {
          const active = panel === id;
          return (
            <button
              key={id}
              type="button"
              aria-current={active ? 'page' : undefined}
              onClick={() => setPanel(id)}
              className={`flex flex-col items-center gap-0.5 rounded-lg px-1 py-1.5 transition ${
                active ? 'bg-[rgba(var(--accent-rgb),0.18)] text-white' : 'text-[var(--accent)]/80'
              }`}
            >
              <Icon className={`h-5 w-5 ${active ? 'drop-shadow-[0_0_6px_var(--accent)]' : ''}`} />
              <span className="font-display text-[0.5rem] uppercase tracking-[0.12em]">{t(label)}</span>
            </button>
          );
        })}
      </nav>
    );
  }

  return (
    <nav aria-label="Command center" className="flex flex-wrap items-center justify-center gap-2">
      {ITEMS.map(({ id, icon: Icon, label }) => {
        const active = panel === id;
        return (
          <button
            key={id}
            type="button"
            aria-current={active ? 'page' : undefined}
            onClick={() => setPanel(id)}
            className={`flex items-center gap-2 rounded-full border px-3.5 py-2 font-display text-[0.6rem] uppercase tracking-[0.18em] transition ${
              active
                ? 'border-[var(--accent)] bg-[rgba(var(--accent-rgb),0.25)] text-white shadow-[0_0_18px_rgba(var(--accent-rgb),0.5)]'
                : 'border-[rgba(var(--accent-rgb),0.35)] text-[var(--accent)] hover:bg-[rgba(var(--accent-rgb),0.12)] hover:shadow-[0_0_14px_rgba(var(--accent-rgb),0.3)]'
            }`}
          >
            <Icon className="h-4 w-4" />
            {t(label)}
          </button>
        );
      })}
    </nav>
  );
}
