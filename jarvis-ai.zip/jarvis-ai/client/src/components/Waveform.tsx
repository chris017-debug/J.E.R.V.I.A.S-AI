import { useEffect, useRef } from 'react';
import type { Mode } from '../types';

const COLORS: Record<Mode, string> = {
  idle: '25,211,255',
  listening: '56,255,215',
  thinking: '110,168,255',
  speaking: '125,243,255',
};

const TARGET_AMP: Record<Mode, number> = {
  idle: 0.07,
  listening: 0.6,
  thinking: 0.28,
  speaking: 0.85,
};

/** Animated sine-wave audio visualiser that reacts to the AI mode. */
export function Waveform({ mode, className = '' }: { mode: Mode; className?: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const modeRef = useRef<Mode>(mode);
  modeRef.current = mode;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    let width = 0;
    let height = 0;
    let raf = 0;
    let t = 0;
    let amp = TARGET_AMP.idle;
    let last = performance.now();

    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      width = canvas.clientWidth;
      height = canvas.clientHeight;
      canvas.width = Math.round(width * dpr);
      canvas.height = Math.round(height * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };

    const frame = (now: number) => {
      const dt = Math.min((now - last) / 1000, 0.05);
      last = now;
      t += dt;
      const m = modeRef.current;
      amp += (TARGET_AMP[m] - amp) * 0.08;
      const rgb = COLORS[m];
      const live = m === 'listening' || m === 'speaking';

      ctx.clearRect(0, 0, width, height);
      for (let k = 0; k < 3; k++) {
        ctx.beginPath();
        for (let x = 0; x <= width; x += 3) {
          const nx = x / width;
          const envelope = Math.pow(Math.sin(Math.PI * nx), 1.4);
          const flutter = live ? 0.65 + 0.35 * Math.sin(t * 7 + k * 1.7 + nx * 5) : 1;
          const scan = m === 'thinking' ? Math.exp(-Math.pow((nx - ((t * 0.7) % 1)) * 7, 2)) * 2.4 + 0.35 : 1;
          const y =
            height / 2 +
            Math.sin(nx * (7 + k * 3) * Math.PI + t * (1.6 + k * 0.8)) *
              (height * 0.42) *
              amp *
              envelope *
              flutter *
              scan *
              (1 - k * 0.24);
          if (x === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.strokeStyle = `rgba(${rgb},${0.9 - k * 0.28})`;
        ctx.lineWidth = 2 - k * 0.4;
        ctx.shadowColor = `rgba(${rgb},0.9)`;
        ctx.shadowBlur = k === 0 ? 10 : 0;
        ctx.stroke();
      }
      ctx.shadowBlur = 0;
      if (!reduce) raf = requestAnimationFrame(frame);
    };

    const onVisibility = () => {
      if (document.hidden) cancelAnimationFrame(raf);
      else if (!reduce) {
        last = performance.now();
        raf = requestAnimationFrame(frame);
      }
    };

    resize();
    raf = requestAnimationFrame(frame);
    window.addEventListener('resize', resize);
    document.addEventListener('visibilitychange', onVisibility);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', resize);
      document.removeEventListener('visibilitychange', onVisibility);
    };
  }, []);

  return <canvas ref={canvasRef} className={`block h-full w-full ${className}`} aria-hidden />;
}
