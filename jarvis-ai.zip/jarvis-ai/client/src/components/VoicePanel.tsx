import { AudioLines, Mic, Square, VolumeX } from 'lucide-react';
import { useT } from '../lib/hooks';
import { sttSupported, ttsSupported, voicesForLang } from '../lib/speech';
import { useStore } from '../store';
import { PanelShell } from './ui';

export function VoicePanel() {
  const t = useT();
  const mode = useStore((s) => s.mode);
  const handsFree = useStore((s) => s.handsFree);
  const interim = useStore((s) => s.interim);
  const lastHeard = useStore((s) => s.lastHeard);
  const lastReply = useStore((s) => s.lastReply);
  const lang = useStore((s) => s.settings.lang);
  const voices = useStore((s) => s.voices);
  const startHandsFree = useStore((s) => s.startHandsFree);
  const stopAll = useStore((s) => s.stopAll);

  const missingSwVoice = lang === 'sw' && ttsSupported && voices.length > 0 && voicesForLang(voices, 'sw').length === 0;

  const status =
    mode === 'listening'
      ? t('modeListening')
      : mode === 'thinking'
        ? t('modeThinking')
        : mode === 'speaking'
          ? t('modeSpeaking')
          : t('modeIdle');

  return (
    <PanelShell title={t('panelVoice')} icon={AudioLines}>
      <div className="flex h-full flex-col gap-3 overflow-y-auto p-4">
        {!sttSupported && (
          <p className="rounded-lg border border-[#ffc247]/50 bg-[#ffc247]/10 px-3 py-2 text-sm text-[#ffe3a3]">{t('voiceNoStt')}</p>
        )}
        {missingSwVoice && (
          <p className="rounded-lg border border-[#ffc247]/50 bg-[#ffc247]/10 px-3 py-2 text-sm text-[#ffe3a3]">{t('voiceNoSwVoice')}</p>
        )}

        <div className="flex flex-col items-center gap-3 py-2">
          <button
            type="button"
            onClick={() => (handsFree ? stopAll() : void startHandsFree())}
            aria-pressed={handsFree}
            className={`relative grid h-24 w-24 place-items-center rounded-full border-2 transition ${
              handsFree
                ? 'border-[var(--accent)] bg-[rgba(var(--accent-rgb),0.28)] text-white shadow-[0_0_34px_var(--accent)]'
                : 'border-[rgba(var(--accent-rgb),0.6)] bg-[rgba(var(--accent-rgb),0.08)] text-[var(--accent)] hover:shadow-[0_0_26px_rgba(var(--accent-rgb),0.5)]'
            }`}
          >
            {handsFree && <span className="rx-ping !inset-[-10px]" style={{ animation: 'ping-out 1.6s ease-out infinite' }} />}
            {handsFree ? <Square className="h-8 w-8 fill-current" /> : <Mic className="h-10 w-10" />}
          </button>
          <div className="text-center">
            <div className="font-display text-xs tracking-[0.3em] text-white glow-text">{status}</div>
            <div className="mt-1 text-sm font-semibold tracking-wide text-[var(--accent)]">
              {handsFree ? t('voiceStop') : t('voiceStart')}
            </div>
          </div>
          <p className="max-w-xs text-center text-sm text-jarvis-200/65">{t('voiceHint')}</p>
        </div>

        <div className="rounded-xl border border-[rgba(var(--accent-rgb),0.22)] bg-black/35 p-3">
          <div className="hud-label mb-1">{t('voiceYouSaid')}</div>
          <p className="min-h-[1.5rem] text-[1.02rem] text-white">
            {mode === 'listening' && interim ? interim : lastHeard || <span className="text-jarvis-200/40">{t('voiceNothingYet')}</span>}
          </p>
        </div>

        <div className="rounded-xl border border-[rgba(var(--accent-rgb),0.22)] bg-black/35 p-3">
          <div className="hud-label mb-1">{t('voiceLastReply')}</div>
          <p className="max-h-40 min-h-[1.5rem] overflow-y-auto text-[1.02rem] text-jarvis-50">
            {lastReply || <span className="text-jarvis-200/40">—</span>}
          </p>
        </div>

        {mode === 'speaking' && (
          <button type="button" onClick={stopAll} className="hud-btn self-center">
            <VolumeX className="h-4 w-4" /> {t('stopSpeaking')}
          </button>
        )}
      </div>
    </PanelShell>
  );
}
