import type { CSSProperties } from 'react';
import { useStore } from '../store';
import { useT } from '../lib/hooks';

const TICKS = Array.from({ length: 120 }, (_, i) => i);
const BARS = Array.from({ length: 72 }, (_, i) => i);
const HEX = Array.from({ length: 6 }, (_, i) => {
  const a = (Math.PI / 3) * i - Math.PI / 2;
  return `${(200 + 44 * Math.cos(a)).toFixed(2)},${(200 + 44 * Math.sin(a)).toFixed(2)}`;
}).join(' ');

function spin(duration: string): CSSProperties {
  return { ['--d' as string]: duration } as CSSProperties;
}

interface Props {
  onClick: () => void;
  label: string;
}

/**
 * The animated circular AI reactor. Colours and speeds come from the `data-mode`
 * attribute on an ancestor (set in App). Tapping it starts/stops listening.
 */
export function Reactor({ onClick, label }: Props) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={label}
      title={label}
      className="rx relative block aspect-square w-full cursor-pointer select-none rounded-full outline-none focus-visible:ring-2 focus-visible:ring-jarvis-300/70"
    >
      {/* soft halo */}
      <span
        aria-hidden
        className="absolute inset-[6%] rounded-full opacity-60 blur-2xl transition-colors duration-500"
        style={{ background: 'radial-gradient(circle, rgba(var(--accent-rgb),0.35), transparent 68%)' }}
      />
      <span aria-hidden className="rx-ping" />
      <span aria-hidden className="rx-ping" />

      <svg viewBox="0 0 400 400" className="relative h-full w-full" role="img" aria-hidden>
        <defs>
          <radialGradient id="rxCore" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#ffffff" stopOpacity="0.95" />
            <stop offset="35%" stopColor="currentColor" stopOpacity="0.85" />
            <stop offset="100%" stopColor="currentColor" stopOpacity="0" />
          </radialGradient>
          <radialGradient id="rxDisc" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="currentColor" stopOpacity="0.28" />
            <stop offset="100%" stopColor="currentColor" stopOpacity="0.02" />
          </radialGradient>
          <linearGradient id="rxSweep" x1="1" y1="0" x2="0" y2="0">
            <stop offset="0%" stopColor="currentColor" stopOpacity="0" />
            <stop offset="100%" stopColor="currentColor" stopOpacity="0.5" />
          </linearGradient>
        </defs>

        {/* outer tick ring */}
        <g className="rx-spin" style={spin('120s')} stroke="currentColor" opacity="0.7">
          {TICKS.map((i) => (
            <line
              key={i}
              x1="200"
              y1="10"
              x2="200"
              y2={i % 5 === 0 ? 24 : 18}
              strokeWidth={i % 5 === 0 ? 2 : 1}
              transform={`rotate(${i * 3} 200 200)`}
            />
          ))}
        </g>

        {/* dashed ring (counter-clockwise) */}
        <g className="rx-spin rev" style={spin('46s')}>
          <circle cx="200" cy="200" r="168" fill="none" stroke="currentColor" strokeWidth="1.5" strokeDasharray="2 9" opacity="0.8" />
        </g>

        {/* thick segmented ring */}
        <g className="rx-spin" style={spin('26s')}>
          <circle
            cx="200"
            cy="200"
            r="148"
            fill="none"
            stroke="currentColor"
            strokeWidth="7"
            pathLength="100"
            strokeDasharray="17 8"
            strokeLinecap="round"
            opacity="0.85"
          />
        </g>

        {/* thin ring with gaps */}
        <g className="rx-spin rev" style={spin('18s')}>
          <circle
            cx="200"
            cy="200"
            r="128"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            pathLength="100"
            strokeDasharray="62 38"
            opacity="0.9"
          />
        </g>

        {/* radar sweep */}
        <g className="rx-spin" style={spin('7s')}>
          <path d="M200 200 L200 36 A164 164 0 0 1 313.5 81.5 Z" fill="url(#rxSweep)" />
          <line x1="200" y1="200" x2="200" y2="36" stroke="currentColor" strokeWidth="1.5" opacity="0.9" />
        </g>

        {/* radial waveform bars */}
        <g fill="currentColor">
          {BARS.map((i) => (
            <g key={i} transform={`rotate(${i * 5} 200 200)`}>
              <rect
                className="rx-bar"
                x="198.5"
                y="90"
                width="3"
                height="22"
                rx="1.5"
                style={
                  {
                    ['--i' as string]: i,
                    ['--bdel' as string]: `${(i * 37) % 420}ms`,
                    ['--bd' as string]: `${520 + ((i * 53) % 520)}ms`,
                  } as CSSProperties
                }
              />
            </g>
          ))}
        </g>

        {/* inner rings */}
        <circle cx="200" cy="200" r="84" fill="none" stroke="currentColor" strokeWidth="1.5" opacity="0.7" />
        <circle cx="200" cy="200" r="78" fill="url(#rxDisc)" stroke="currentColor" strokeWidth="1" opacity="0.9" />

        {/* reactor coil segments */}
        <g className="rx-spin rev" style={spin('34s')}>
          <circle
            cx="200"
            cy="200"
            r="60"
            fill="none"
            stroke="currentColor"
            strokeWidth="11"
            pathLength="60"
            strokeDasharray="8 2"
            opacity="0.85"
          />
        </g>

        {/* hexagon + core */}
        <g className="rx-spin" style={spin('22s')}>
          <polygon points={HEX} fill="none" stroke="currentColor" strokeWidth="2" opacity="0.95" />
        </g>
        <circle className="rx-core" cx="200" cy="200" r="30" fill="url(#rxCore)" />
        <circle cx="200" cy="200" r="9" fill="#ffffff" opacity="0.95" />
      </svg>
    </button>
  );
}

/** Mode caption shown under the reactor. */
export function ModeLabel() {
  const mode = useStore((s) => s.mode);
  const t = useT();
  const text =
    mode === 'listening'
      ? t('modeListening')
      : mode === 'thinking'
        ? t('modeThinking')
        : mode === 'speaking'
          ? t('modeSpeaking')
          : t('modeIdle');
  return (
    <div className="flex items-center justify-center gap-2" aria-live="polite">
      <span className="dot-pulse h-2 w-2 rounded-full bg-[var(--accent)] shadow-[0_0_10px_var(--accent)]" />
      <span className="font-display text-[0.7rem] tracking-[0.35em] text-[var(--accent)] glow-text sm:text-xs">{text}</span>
    </div>
  );
}
