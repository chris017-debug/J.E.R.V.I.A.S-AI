import { AnimatePresence, motion } from 'framer-motion';
import { AlertTriangle, Info } from 'lucide-react';
import { useEffect } from 'react';
import { useStore } from '../store';

/** Transient notification (errors, confirmations). Tap to dismiss. */
export function Toast() {
  const toast = useStore((s) => s.toast);
  const dismiss = useStore((s) => s.dismissToast);

  useEffect(() => {
    if (!toast) return;
    const id = setTimeout(dismiss, 6000);
    return () => clearTimeout(id);
  }, [toast, dismiss]);

  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-24 z-50 flex justify-center px-4 md:bottom-8">
      <AnimatePresence>
        {toast && (
          <motion.button
            key={toast.id}
            type="button"
            role="alert"
            onClick={dismiss}
            initial={{ opacity: 0, y: 16, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10 }}
            transition={{ duration: 0.2 }}
            className={`pointer-events-auto flex max-w-md items-start gap-3 rounded-xl border px-4 py-3 text-left text-[0.95rem] font-medium backdrop-blur-md ${
              toast.kind === 'error'
                ? 'border-[rgba(255,92,120,0.6)] bg-[rgba(40,4,12,0.88)] text-[#ffd3db] shadow-[0_0_24px_rgba(255,92,120,0.3)]'
                : 'border-[rgba(var(--accent-rgb),0.6)] bg-[rgba(2,20,30,0.9)] text-jarvis-100 shadow-[0_0_24px_rgba(var(--accent-rgb),0.3)]'
            }`}
          >
            {toast.kind === 'error' ? (
              <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-[#ff5c78]" />
            ) : (
              <Info className="mt-0.5 h-5 w-5 shrink-0 text-[var(--accent)]" />
            )}
            <span>{toast.text}</span>
          </motion.button>
        )}
      </AnimatePresence>
    </div>
  );
}
