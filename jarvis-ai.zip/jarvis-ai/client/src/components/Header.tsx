import { formatClock, formatDate, useNow, useOnline } from '../lib/hooks';
import { useStore } from '../store';
import type { Lang } from '../types';
import { StatusDot } from './ui';

export function LangToggle() {
  const lang = useStore((s) => s.settings.lang);
  const updateSettings = useStore((s) => s.updateSettings);
  const options: Array<{ id: Lang; label: string }> = [
    { id: 'en', label: 'EN' },
    { id: 'sw', label: 'SW' },
  ];
  return (
    <div role="group" aria-label="Language" className="flex overflow-hidden rounded-lg border border-[rgba(var(--accent-rgb),0.4)]">
      {options.map((o) => (
        <button
          key={o.id}
          type="button"
          aria-pressed={lang === o.id}
          onClick={() => updateSettings({ lang: o.id })}
          className={`px-2.5 py-1 font-display text-[0.62rem] tracking-[0.18em] transition ${
            lang === o.id
              ? 'bg-[rgba(var(--accent-rgb),0.3)] text-white shadow-[inset_0_0_10px_rgba(var(--accent-rgb),0.5)]'
              : 'text-[var(--accent)] hover:bg-[rgba(var(--accent-rgb),0.12)]'
          }`}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function Header() {
  const lang = useStore((s) => s.settings.lang);
  const healthError = useStore((s) => s.healthError);
  const online = useOnline();
  const now = useNow();
  const linked = online && !healthError;

  return (
    <header className="relative z-20 flex shrink-0 items-center justify-between gap-3 px-3 pb-1 pt-[max(0.5rem,env(safe-area-inset-top))] sm:px-5">
      <div className="flex items-center gap-2">
        <StatusDot tone={linked ? 'ok' : 'bad'} pulse />
        <span className="hud-label hidden sm:inline">J.A.R.V.I.S // CORE INTERFACE v1.0</span>
        <span className="hud-label sm:hidden">JARVIS // v1.0</span>
      </div>
      <div className="flex items-center gap-3">
        <span className="hud-label hidden md:inline">{formatDate(now, lang, false)}</span>
        <span className="font-display text-sm tracking-[0.2em] text-white glow-text tabular-nums">{formatClock(now)}</span>
        <LangToggle />
      </div>
    </header>
  );
}

export function TitleBlock() {
  return (
    <div className="text-center">
      <h1 className="font-display text-[1.45rem] font-bold tracking-[0.28em] text-white glow-text sm:text-3xl lg:text-[2.6rem]">
        J.A.R.V.I.S
      </h1>
      <p className="hud-label mt-1 !text-[0.5rem] !tracking-[0.17em] sm:!text-[0.62rem] sm:!tracking-[0.3em]">
        JUST A RATHER VERY INTELLIGENT SYSTEM
      </p>
    </div>
  );
}
