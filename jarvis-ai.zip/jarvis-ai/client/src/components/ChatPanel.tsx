import { AnimatePresence, motion } from 'framer-motion';
import { AlertTriangle, MessageSquare, Mic, Plus, RotateCcw, Send, Square, Volume2 } from 'lucide-react';
import { useEffect, useRef, type FormEvent, type KeyboardEvent } from 'react';
import ReactMarkdown from 'react-markdown';
import { useT } from '../lib/hooks';
import { ttsSupported } from '../lib/speech';
import { selectActive, useStore } from '../store';
import type { Message } from '../types';
import { IconButton, PanelShell } from './ui';

function Bubble({ message, isLast }: { message: Message; isLast: boolean }) {
  const t = useT();
  const speakText = useStore((s) => s.speakText);
  const retryLast = useStore((s) => s.retryLast);
  const busy = useStore((s) => s.busy);

  if (message.role === 'user') {
    return (
      <div className="flex justify-end">
        <div className="max-w-[88%] rounded-2xl rounded-br-md border border-[rgba(var(--accent-rgb),0.45)] bg-[rgba(var(--accent-rgb),0.16)] px-3.5 py-2 text-[1rem] text-white shadow-[0_0_14px_rgba(var(--accent-rgb),0.15)]">
          <div className="hud-label mb-0.5 !text-[0.5rem] !text-jarvis-200/70">{t('you')}</div>
          <p className="whitespace-pre-wrap break-words">{message.content}</p>
        </div>
      </div>
    );
  }

  if (message.role === 'error') {
    return (
      <div className="flex justify-start">
        <div className="max-w-[92%] rounded-2xl rounded-bl-md border border-[rgba(255,92,120,0.5)] bg-[rgba(255,92,120,0.08)] px-3.5 py-2 text-[0.97rem] text-[#ffd3db]">
          <div className="mb-1 flex items-center gap-1.5 font-display text-[0.5rem] uppercase tracking-[0.2em] text-[#ff5c78]">
            <AlertTriangle className="h-3.5 w-3.5" /> J.A.R.V.I.S
          </div>
          <p className="break-words">{message.content}</p>
          {isLast && (
            <button type="button" onClick={() => void retryLast()} disabled={busy} className="hud-btn danger mt-2 !px-3 !py-1.5 !text-sm">
              <RotateCcw className="h-3.5 w-3.5" /> {t('retry')}
            </button>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="flex justify-start">
      <div className="max-w-[94%] rounded-2xl rounded-bl-md border border-[rgba(var(--accent-rgb),0.25)] bg-black/45 px-3.5 py-2 text-[1rem] text-jarvis-50">
        <div className="mb-0.5 flex items-center gap-2">
          <span className="hud-label !text-[0.5rem]">{t('jarvis')}</span>
          {message.demo && (
            <span className="rounded border border-[#ffc247]/60 px-1 font-display text-[0.45rem] tracking-widest text-[#ffc247]">
              {t('demoBadge')}
            </span>
          )}
        </div>
        <div className="md break-words">
          <ReactMarkdown>{message.content}</ReactMarkdown>
        </div>
        {ttsSupported && (
          <button
            type="button"
            onClick={() => void speakText(message.content)}
            aria-label={t('readAloud')}
            title={t('readAloud')}
            className="mt-1.5 inline-flex items-center gap-1 text-xs text-[var(--accent)]/70 transition hover:text-[var(--accent)]"
          >
            <Volume2 className="h-3.5 w-3.5" /> {t('readAloud')}
          </button>
        )}
      </div>
    </div>
  );
}

export function ChatPanel() {
  const t = useT();
  const convo = useStore(selectActive);
  const busy = useStore((s) => s.busy);
  const mode = useStore((s) => s.mode);
  const draft = useStore((s) => s.draft);
  const interim = useStore((s) => s.interim);
  const setDraft = useStore((s) => s.setDraft);
  const sendMessage = useStore((s) => s.sendMessage);
  const dictate = useStore((s) => s.dictate);
  const newConversation = useStore((s) => s.newConversation);
  const stopAll = useStore((s) => s.stopAll);

  const endRef = useRef<HTMLDivElement>(null);
  const areaRef = useRef<HTMLTextAreaElement>(null);
  const messages = convo?.messages ?? [];
  const listening = mode === 'listening';
  const shown = listening && interim ? interim : draft;

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
  }, [messages.length, busy]);

  useEffect(() => {
    const el = areaRef.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = `${Math.min(el.scrollHeight, 120)}px`;
  }, [shown]);

  const submit = (e?: FormEvent) => {
    e?.preventDefault();
    if (!draft.trim() || busy) return;
    void sendMessage(draft);
  };

  const onKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) {
      e.preventDefault();
      submit();
    }
  };

  const suggestions = [t('sug1'), t('sug2'), t('sug3'), t('sug4')];

  return (
    <PanelShell
      title={t('panelChat')}
      icon={MessageSquare}
      actions={<IconButton icon={Plus} label={t('newChat')} onClick={() => newConversation()} />}
    >
      <div className="flex h-full min-h-0 flex-col">
        <div className="min-h-0 flex-1 space-y-3 overflow-y-auto px-3 py-3" aria-live="polite">
          {messages.length === 0 && (
            <div className="flex h-full flex-col items-center justify-center gap-4 px-2 text-center">
              <div>
                <p className="font-display text-sm tracking-[0.2em] text-white glow-text">{t('emptyTitle')}</p>
                <p className="mx-auto mt-1 max-w-xs text-sm text-jarvis-200/65">{t('emptyHint')}</p>
              </div>
              <div className="flex flex-wrap justify-center gap-2">
                {suggestions.map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => void sendMessage(s)}
                    disabled={busy}
                    className="rounded-full border border-[rgba(var(--accent-rgb),0.35)] bg-[rgba(var(--accent-rgb),0.07)] px-3 py-1.5 text-sm text-jarvis-100 transition hover:bg-[rgba(var(--accent-rgb),0.18)] disabled:opacity-40"
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}

          <AnimatePresence initial={false}>
            {messages.map((m, i) => (
              <motion.div
                key={m.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.22 }}
              >
                <Bubble message={m} isLast={i === messages.length - 1} />
              </motion.div>
            ))}
            {busy && (
              <motion.div
                key="thinking"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex items-center gap-3 px-1"
              >
                <div className="flex items-center gap-1.5">
                  <span className="think-dot" />
                  <span className="think-dot" />
                  <span className="think-dot" />
                </div>
                <span className="hud-label">{t('thinkingLabel')}</span>
              </motion.div>
            )}
          </AnimatePresence>
          <div ref={endRef} />
        </div>

        <form
          onSubmit={submit}
          className="flex shrink-0 items-end gap-2 border-t border-[rgba(var(--accent-rgb),0.2)] bg-black/40 p-2.5"
        >
          <button
            type="button"
            onClick={() => void dictate()}
            aria-label={listening ? t('micStop') : t('micStart')}
            title={listening ? t('micStop') : t('micStart')}
            aria-pressed={listening}
            className={`grid h-11 w-11 shrink-0 place-items-center rounded-xl border transition ${
              listening
                ? 'dot-pulse border-[var(--accent)] bg-[rgba(var(--accent-rgb),0.35)] text-white shadow-[0_0_18px_var(--accent)]'
                : 'border-[rgba(var(--accent-rgb),0.45)] text-[var(--accent)] hover:bg-[rgba(var(--accent-rgb),0.15)]'
            }`}
          >
            {listening ? <Square className="h-4 w-4 fill-current" /> : <Mic className="h-5 w-5" />}
          </button>

          <textarea
            ref={areaRef}
            rows={1}
            value={shown}
            readOnly={listening}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={onKeyDown}
            placeholder={listening ? t('listeningNow') : t('chatPlaceholder')}
            aria-label={t('chatPlaceholder')}
            maxLength={4000}
            className="hud-input max-h-[120px] min-h-[44px] flex-1 resize-none !py-2.5 leading-snug"
          />

          {mode === 'speaking' ? (
            <button
              type="button"
              onClick={stopAll}
              aria-label={t('stopSpeaking')}
              title={t('stopSpeaking')}
              className="hud-btn !h-11 !w-11 !p-0"
            >
              <Square className="h-4 w-4 fill-current" />
            </button>
          ) : (
            <button
              type="submit"
              disabled={!draft.trim() || busy}
              aria-label={t('send')}
              title={t('send')}
              className="hud-btn !h-11 !w-11 shrink-0 !p-0"
            >
              <Send className="h-5 w-5" />
            </button>
          )}
        </form>
      </div>
    </PanelShell>
  );
}
