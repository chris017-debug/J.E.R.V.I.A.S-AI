import type { LucideIcon } from 'lucide-react';
import type { ReactNode } from 'react';
import type { Tone } from '../lib/status';

export const TONE_TEXT: Record<Tone, string> = {
  ok: 'text-[#38ffd7]',
  warn: 'text-[#ffc247]',
  bad: 'text-[#ff5c78]',
  dim: 'text-jarvis-300/60',
};

export const TONE_DOT: Record<Tone, string> = {
  ok: 'bg-[#38ffd7] shadow-[0_0_8px_#38ffd7]',
  warn: 'bg-[#ffc247] shadow-[0_0_8px_#ffc247]',
  bad: 'bg-[#ff5c78] shadow-[0_0_8px_#ff5c78]',
  dim: 'bg-jarvis-300/40',
};

export function StatusDot({ tone, pulse = false }: { tone: Tone; pulse?: boolean }) {
  return <span className={`inline-block h-2 w-2 shrink-0 rounded-full ${TONE_DOT[tone]} ${pulse ? 'dot-pulse' : ''}`} />;
}

export function StatusRow({
  label,
  value,
  tone,
  detail,
}: {
  label: string;
  value: string;
  tone: Tone;
  detail?: string;
}) {
  return (
    <div className="flex items-center justify-between gap-3 border-b border-[rgba(var(--accent-rgb),0.12)] py-2 last:border-b-0">
      <div className="min-w-0">
        <div className="text-sm font-semibold tracking-wide text-jarvis-100/90">{label}</div>
        {detail && <div className="truncate text-xs text-jarvis-200/55">{detail}</div>}
      </div>
      <div className={`flex shrink-0 items-center gap-2 font-display text-[0.62rem] tracking-[0.16em] ${TONE_TEXT[tone]}`}>
        <StatusDot tone={tone} pulse={tone === 'ok'} />
        {value}
      </div>
    </div>
  );
}

export function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-[rgba(var(--accent-rgb),0.2)] bg-black/30 px-3 py-2">
      <div className="hud-label !text-[0.55rem]">{label}</div>
      <div className="mt-0.5 font-display text-base tracking-wider text-white glow-text tabular-nums">{value}</div>
    </div>
  );
}

export function Toggle({
  checked,
  onChange,
  label,
  disabled = false,
}: {
  checked: boolean;
  onChange: (value: boolean) => void;
  label: string;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      disabled={disabled}
      onClick={() => onChange(!checked)}
      className="flex w-full items-center justify-between gap-3 rounded-lg px-1 py-2 text-left disabled:opacity-40"
    >
      <span className="text-[0.95rem] font-semibold text-jarvis-100/90">{label}</span>
      <span
        className={`relative h-6 w-11 shrink-0 rounded-full border transition-colors ${
          checked
            ? 'border-[var(--accent)] bg-[rgba(var(--accent-rgb),0.35)] shadow-[0_0_12px_rgba(var(--accent-rgb),0.5)]'
            : 'border-jarvis-700 bg-black/50'
        }`}
      >
        <span
          className={`absolute top-0.5 rounded-full bg-white transition-all ${checked ? 'left-[22px]' : 'left-0.5'}`}
          style={{ width: 18, height: 18 }}
        />
      </span>
    </button>
  );
}

export function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="rounded-xl border border-[rgba(var(--accent-rgb),0.18)] bg-black/25 p-3">
      <h3 className="hud-label mb-2">{title}</h3>
      <div className="space-y-2">{children}</div>
    </section>
  );
}

export function PanelShell({
  title,
  icon: Icon,
  actions,
  children,
}: {
  title: string;
  icon: LucideIcon;
  actions?: ReactNode;
  children: ReactNode;
}) {
  return (
    <section className="holo-panel flex h-full min-h-0 flex-col">
      <header className="flex shrink-0 items-center justify-between gap-2 border-b border-[rgba(var(--accent-rgb),0.2)] px-4 py-2.5">
        <div className="flex min-w-0 items-center gap-2">
          <Icon className="h-4 w-4 shrink-0 text-[var(--accent)]" />
          <h2 className="truncate font-display text-[0.7rem] uppercase tracking-[0.25em] text-white glow-text">{title}</h2>
        </div>
        {actions && <div className="flex shrink-0 items-center gap-1.5">{actions}</div>}
      </header>
      <div className="min-h-0 flex-1 overflow-hidden rounded-b-[14px]">{children}</div>
    </section>
  );
}

export function IconButton({
  icon: Icon,
  label,
  onClick,
  active = false,
  danger = false,
}: {
  icon: LucideIcon;
  label: string;
  onClick: () => void;
  active?: boolean;
  danger?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={label}
      title={label}
      className={`grid h-8 w-8 place-items-center rounded-lg border transition ${
        danger
          ? 'border-[rgba(255,92,120,0.4)] text-[#ff9fb1] hover:bg-[rgba(255,92,120,0.15)]'
          : active
            ? 'border-[var(--accent)] bg-[rgba(var(--accent-rgb),0.25)] text-white'
            : 'border-[rgba(var(--accent-rgb),0.35)] text-[var(--accent)] hover:bg-[rgba(var(--accent-rgb),0.15)]'
      }`}
    >
      <Icon className="h-4 w-4" />
    </button>
  );
}

/** Copies text, with a fallback for pages served over plain http. */
export async function copyText(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    try {
      const area = document.createElement('textarea');
      area.value = text;
      area.style.position = 'fixed';
      area.style.opacity = '0';
      document.body.appendChild(area);
      area.select();
      const ok = document.execCommand('copy');
      area.remove();
      return ok;
    } catch {
      return false;
    }
  }
}
