export type Lang = 'en' | 'sw';
export type Mode = 'idle' | 'listening' | 'thinking' | 'speaking';
export type PanelId = 'chat' | 'voice' | 'status' | 'settings' | 'history';

export interface Message {
  id: string;
  role: 'user' | 'assistant' | 'error';
  content: string;
  ts: number;
  /** True when the server answered in demo mode (no AI key configured). */
  demo?: boolean;
  /** True when the reply came from a local command (time, open settings, …). */
  local?: boolean;
}

export interface Conversation {
  id: string;
  /** Empty string means "not titled yet"; the UI shows a localized placeholder. */
  title: string;
  createdAt: number;
  updatedAt: number;
  messages: Message[];
}

export interface Settings {
  lang: Lang;
  voiceOutput: boolean;
  autoSpeak: boolean;
  autoSend: boolean;
  rate: number;
  pitch: number;
  voiceURI: string;
  passcode: string;
}

export interface Health {
  ok: boolean;
  name: string;
  version: string;
  uptimeSec: number;
  ai: { configured: boolean; provider: string; model: string };
  db: { enabled: boolean; connected: boolean };
  passcodeRequired: boolean;
  /** Round-trip time measured by the browser. */
  latencyMs: number;
}

export const PANELS: PanelId[] = ['chat', 'voice', 'status', 'settings', 'history'];
