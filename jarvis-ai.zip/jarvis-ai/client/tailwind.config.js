/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        jarvis: {
          50: '#e6fcff',
          100: '#bff7ff',
          200: '#8aefff',
          300: '#4de4ff',
          400: '#19d3ff',
          500: '#00b8f0',
          600: '#0090c4',
          700: '#006c97',
          800: '#074e6e',
          900: '#0a3550',
          950: '#03131f',
        },
      },
      fontFamily: {
        display: ['Orbitron', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        sans: ['Rajdhani', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        mono: ['ui-monospace', 'SFMono-Regular', 'Menlo', 'Consolas', 'monospace'],
      },
      boxShadow: {
        glow: '0 0 18px rgba(25, 211, 255, 0.35)',
        'glow-lg': '0 0 40px rgba(25, 211, 255, 0.45)',
      },
    },
  },
  plugins: [],
};
