import react from '@vitejs/plugin-react';
import { defineConfig } from 'vite';

// During development the API lives on :8787. Proxying "/api" keeps everything same-origin,
// so no CORS setup is needed and the phone can reach it through the dev server too.
export default defineConfig({
  plugins: [react()],
  server: {
    host: true, // expose on your Wi-Fi so a phone can open http://<your-pc-ip>:5173
    port: 5173,
    proxy: {
      '/api': { target: 'http://localhost:8787', changeOrigin: true },
    },
  },
  preview: {
    host: true,
    port: 4173,
    proxy: {
      '/api': { target: 'http://localhost:8787', changeOrigin: true },
    },
  },
  build: {
    sourcemap: false,
    chunkSizeWarningLimit: 900,
  },
});
