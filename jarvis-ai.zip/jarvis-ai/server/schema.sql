-- J.A.R.V.I.S chat history schema.
-- The server creates these tables automatically on startup, so running this file is optional.
-- For Supabase you may also paste it into: Dashboard → SQL Editor → New query → Run.

create table if not exists jarvis_conversations (
  id uuid primary key,
  device_id text not null,
  title text not null default 'New conversation',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists jarvis_conversations_device_idx
  on jarvis_conversations (device_id, updated_at desc);

create table if not exists jarvis_messages (
  id bigserial primary key,
  conversation_id uuid not null references jarvis_conversations(id) on delete cascade,
  role text not null check (role in ('user', 'assistant')),
  content text not null,
  created_at timestamptz not null default now()
);
create index if not exists jarvis_messages_conv_idx
  on jarvis_messages (conversation_id, id);

-- Lock the tables from Supabase's public (anon) API. Only your server, which connects
-- with the database connection string, can read or write them.
alter table jarvis_conversations enable row level security;
alter table jarvis_messages enable row level security;
