import { Router } from 'express';
import { z } from 'zod';
import { requestLang, requireDeviceId, requirePasscode, sendError } from '../middleware/auth';
import { AiError, askAi, friendlyMessage } from '../services/ai';
import { dbReady, saveExchange } from '../services/db';

const router = Router();

const bodySchema = z.object({
  messages: z
    .array(
      z.object({
        role: z.enum(['user', 'assistant']),
        content: z.string().trim().min(1).max(4000),
      }),
    )
    .min(1)
    .max(40),
  lang: z.enum(['en', 'sw']).default('en'),
  conversationId: z.string().uuid().optional(),
  title: z.string().max(120).optional(),
});

router.post('/chat', requirePasscode, requireDeviceId, async (req, res) => {
  const parsed = bodySchema.safeParse(req.body);
  if (!parsed.success) {
    sendError(req, res, 400, 'bad_request');
    return;
  }
  const { messages, lang, conversationId, title } = parsed.data;

  const last = messages[messages.length - 1];
  if (last.role !== 'user') {
    sendError(req, res, 400, 'bad_request');
    return;
  }

  try {
    const result = await askAi(messages, lang);

    // Best-effort cloud backup: a database problem must never break the conversation.
    if (!result.demo && conversationId && dbReady()) {
      saveExchange({
        deviceId: res.locals.deviceId as string,
        conversationId,
        title: title?.trim() || last.content.slice(0, 60),
        userText: last.content,
        assistantText: result.reply,
      }).catch((err) => console.error('[db] saveExchange failed:', err instanceof Error ? err.message : err));
    }

    res.json({ reply: result.reply, model: result.model, demo: result.demo });
  } catch (err) {
    if (err instanceof AiError) {
      res.status(err.status === 429 ? 429 : 502).json({
        error: { code: err.code, message: friendlyMessage(err.code, lang) },
      });
      return;
    }
    console.error('[chat] unexpected error:', err instanceof Error ? err.message : err);
    sendError(req, res, 500, 'internal', friendlyMessage('internal', requestLang(req)));
  }
});

export default router;
