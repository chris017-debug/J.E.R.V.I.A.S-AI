import { Router } from 'express';
import { z } from 'zod';
import { requireDeviceId, requirePasscode, sendError } from '../middleware/auth';
import {
  dbEnabled,
  dbReady,
  deleteAll,
  deleteConversation,
  exportAll,
  getConversation,
  listConversations,
} from '../services/db';

const router = Router();
router.use('/history', requirePasscode, requireDeviceId);

const idSchema = z.string().uuid();

function deviceOf(res: { locals: Record<string, unknown> }): string {
  return res.locals.deviceId as string;
}

router.get('/history', async (_req, res) => {
  try {
    res.json({ enabled: dbEnabled && dbReady(), conversations: await listConversations(deviceOf(res)) });
  } catch (err) {
    console.error('[history] list failed:', err instanceof Error ? err.message : err);
    res.status(500).json({ error: { code: 'internal', message: 'History is unavailable right now.' } });
  }
});

// Must be declared before "/history/:id".
router.get('/history/export', async (_req, res) => {
  try {
    res.json({ enabled: dbEnabled && dbReady(), conversations: await exportAll(deviceOf(res)) });
  } catch (err) {
    console.error('[history] export failed:', err instanceof Error ? err.message : err);
    res.status(500).json({ error: { code: 'internal', message: 'History is unavailable right now.' } });
  }
});

router.get('/history/:id', async (req, res) => {
  const id = idSchema.safeParse(req.params.id);
  if (!id.success) {
    sendError(req, res, 400, 'bad_request');
    return;
  }
  try {
    const convo = await getConversation(deviceOf(res), id.data);
    if (!convo) {
      res.status(404).json({ error: { code: 'not_found', message: 'Conversation not found.' } });
      return;
    }
    res.json(convo);
  } catch (err) {
    console.error('[history] get failed:', err instanceof Error ? err.message : err);
    res.status(500).json({ error: { code: 'internal', message: 'History is unavailable right now.' } });
  }
});

router.delete('/history/:id', async (req, res) => {
  const id = idSchema.safeParse(req.params.id);
  if (!id.success) {
    sendError(req, res, 400, 'bad_request');
    return;
  }
  try {
    await deleteConversation(deviceOf(res), id.data);
    res.json({ ok: true });
  } catch (err) {
    console.error('[history] delete failed:', err instanceof Error ? err.message : err);
    res.status(500).json({ error: { code: 'internal', message: 'Could not delete right now.' } });
  }
});

router.delete('/history', async (_req, res) => {
  try {
    await deleteAll(deviceOf(res));
    res.json({ ok: true });
  } catch (err) {
    console.error('[history] clear failed:', err instanceof Error ? err.message : err);
    res.status(500).json({ error: { code: 'internal', message: 'Could not clear right now.' } });
  }
});

export default router;
