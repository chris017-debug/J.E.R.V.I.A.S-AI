import { Router } from 'express';
import { aiConfigured, aiProviderName, config } from '../config';
import { dbEnabled, dbPing } from '../services/db';

const router = Router();
const startedAt = Date.now();

router.get('/health', async (_req, res) => {
  const connected = dbEnabled ? await dbPing() : false;
  res.json({
    ok: true,
    name: 'J.A.R.V.I.S',
    version: '1.0.0',
    uptimeSec: Math.round((Date.now() - startedAt) / 1000),
    ai: {
      configured: aiConfigured(),
      provider: aiProviderName(),
      model: aiConfigured() ? config.ai.model : 'demo',
    },
    db: { enabled: dbEnabled, connected },
    passcodeRequired: config.appPasscode.length > 0,
  });
});

export default router;
