import { timingSafeEqual } from 'node:crypto';
import type { NextFunction, Request, Response } from 'express';
import { config } from '../config';
import { friendlyMessage, type Lang } from '../services/ai';

export function requestLang(req: Request): Lang {
  const header = String(req.header('x-lang') ?? '').toLowerCase();
  if (header === 'sw') return 'sw';
  const body = req.body as { lang?: unknown } | undefined;
  return body?.lang === 'sw' ? 'sw' : 'en';
}

export function sendError(req: Request, res: Response, status: number, code: string, message?: string): void {
  res.status(status).json({
    error: { code, message: message ?? friendlyMessage(code, requestLang(req)) },
  });
}

function safeEqual(a: string, b: string): boolean {
  const ab = Buffer.from(a);
  const bb = Buffer.from(b);
  if (ab.length !== bb.length) return false;
  return timingSafeEqual(ab, bb);
}

/** When APP_PASSCODE is set, every protected route must present it in `x-jarvis-passcode`. */
export function requirePasscode(req: Request, res: Response, next: NextFunction): void {
  if (!config.appPasscode) {
    next();
    return;
  }
  const given = String(req.header('x-jarvis-passcode') ?? '');
  if (!safeEqual(given, config.appPasscode)) {
    sendError(req, res, 401, 'unauthorized_app');
    return;
  }
  next();
}

const DEVICE_ID = /^[A-Za-z0-9_-]{8,64}$/;

/** Extracts and validates the anonymous device id used to scope stored history. */
export function requireDeviceId(req: Request, res: Response, next: NextFunction): void {
  const id = String(req.header('x-device-id') ?? '');
  if (!DEVICE_ID.test(id)) {
    sendError(req, res, 400, 'bad_request');
    return;
  }
  res.locals.deviceId = id;
  next();
}
