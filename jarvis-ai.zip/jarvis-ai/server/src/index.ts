import fs from 'node:fs';
import path from 'node:path';
import cors from 'cors';
import express, { type NextFunction, type Request, type Response } from 'express';
import rateLimit from 'express-rate-limit';
import helmet from 'helmet';
import { aiConfigured, aiProviderName, config } from './config';
import { sendError } from './middleware/auth';
import chatRoutes from './routes/chat';
import healthRoutes from './routes/health';
import historyRoutes from './routes/history';
import { dbEnabled, initDb } from './services/db';

const app = express();

// Render, Railway, Fly and most hosts sit behind one reverse proxy.
app.set('trust proxy', 1);
app.disable('x-powered-by');

app.use(helmet());
app.use(
  cors({
    origin(origin, callback) {
      // Same-origin requests and tools like curl send no Origin header.
      if (!origin || config.clientOrigins.includes(origin)) {
        callback(null, true);
        return;
      }
      callback(null, false);
    },
    allowedHeaders: ['Content-Type', 'x-device-id', 'x-jarvis-passcode', 'x-lang'],
    methods: ['GET', 'POST', 'DELETE', 'OPTIONS'],
    maxAge: 600,
  }),
);
app.use(express.json({ limit: '100kb' }));

app.use(
  '/api',
  rateLimit({
    windowMs: 60_000,
    limit: config.rateLimitPerMin,
    standardHeaders: true,
    legacyHeaders: false,
    handler: (req, res) => sendError(req, res, 429, 'too_many_requests'),
  }),
);

app.use('/api', healthRoutes);
app.use('/api', chatRoutes);
app.use('/api', historyRoutes);

app.use('/api', (req, res) => {
  res.status(404).json({ error: { code: 'not_found', message: `No such API route: ${req.method} ${req.path}` } });
});

// In production the same server also serves the built React app (single deployment).
const clientDist = path.resolve(__dirname, '../../client/dist');
if (fs.existsSync(path.join(clientDist, 'index.html'))) {
  app.use(
    express.static(clientDist, {
      index: false,
      setHeaders(res, filePath) {
        // The service worker and HTML must always be revalidated; hashed assets are immutable.
        if (/sw\.js$|\.html$|manifest\.webmanifest$/.test(filePath)) {
          res.setHeader('Cache-Control', 'no-cache');
        } else if (filePath.includes(`${path.sep}assets${path.sep}`)) {
          res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
        }
      },
    }),
  );
  app.get(/^\/(?!api\/).*/, (_req, res) => {
    res.setHeader('Cache-Control', 'no-cache');
    res.sendFile(path.join(clientDist, 'index.html'));
  });
}

// Final error handler (malformed JSON, unexpected exceptions).
// eslint-disable-next-line @typescript-eslint/no-unused-vars
app.use((err: unknown, req: Request, res: Response, _next: NextFunction) => {
  const status = typeof (err as { status?: unknown })?.status === 'number' ? (err as { status: number }).status : 500;
  if (status >= 500) console.error('[server] unhandled error:', err instanceof Error ? err.message : err);
  sendError(req, res, status >= 400 && status < 500 ? 400 : 500, status >= 500 ? 'internal' : 'bad_request');
});

async function main(): Promise<void> {
  if (dbEnabled) await initDb();
  app.listen(config.port, () => {
    console.log('────────────────────────────────────────────');
    console.log(` J.A.R.V.I.S server online on port ${config.port}`);
    console.log(` AI provider : ${aiConfigured() ? `${aiProviderName()} (${config.ai.model})` : 'DEMO MODE (no AI_API_KEY set)'}`);
    console.log(` Database    : ${dbEnabled ? 'PostgreSQL / Supabase' : 'disabled (history stays in the browser)'}`);
    console.log(` Passcode    : ${config.appPasscode ? 'required' : 'not required'}`);
    console.log('────────────────────────────────────────────');
  });
}

main().catch((err) => {
  console.error('Fatal startup error:', err);
  process.exit(1);
});
