import 'dotenv/config';

function num(value: string | undefined, fallback: number): number {
  if (value === undefined || value.trim() === '') return fallback;
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

export const config = {
  port: num(process.env.PORT, 8787),
  nodeEnv: process.env.NODE_ENV ?? 'development',
  isProd: (process.env.NODE_ENV ?? 'development') === 'production',
  clientOrigins: (process.env.CLIENT_ORIGIN ?? 'http://localhost:5173')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean),
  ai: {
    apiKey: (process.env.AI_API_KEY ?? '').trim(),
    baseUrl: (process.env.AI_BASE_URL ?? 'https://api.groq.com/openai/v1').trim().replace(/\/+$/, ''),
    model: (process.env.AI_MODEL ?? 'llama-3.3-70b-versatile').trim(),
    temperature: num(process.env.AI_TEMPERATURE, 0.6),
    maxTokens: num(process.env.AI_MAX_TOKENS, 700),
    timeoutMs: num(process.env.AI_TIMEOUT_MS, 30000),
  },
  databaseUrl: (process.env.DATABASE_URL ?? '').trim(),
  appPasscode: process.env.APP_PASSCODE ?? '',
  rateLimitPerMin: num(process.env.RATE_LIMIT_PER_MIN, 40),
} as const;

/** True when a real API key (not the placeholder from .env.example) is configured. */
export function aiConfigured(): boolean {
  return config.ai.apiKey.length > 8 && !config.ai.apiKey.startsWith('your-');
}

/** Human readable provider name derived from the base URL (never includes secrets). */
export function aiProviderName(): string {
  try {
    const host = new URL(config.ai.baseUrl).hostname;
    if (host.includes('groq')) return 'Groq';
    if (host.includes('openai')) return 'OpenAI';
    if (host.includes('openrouter')) return 'OpenRouter';
    if (host.includes('together')) return 'Together';
    return host;
  } catch {
    return 'custom';
  }
}
