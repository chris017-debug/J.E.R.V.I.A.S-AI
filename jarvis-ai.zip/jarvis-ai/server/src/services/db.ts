import { Pool } from 'pg';
import { config } from '../config';

export interface StoredMessage {
  role: 'user' | 'assistant';
  content: string;
  createdAt: string;
}

export interface ConversationSummary {
  id: string;
  title: string;
  createdAt: string;
  updatedAt: string;
  messageCount: number;
}

export interface ConversationFull extends ConversationSummary {
  messages: StoredMessage[];
}

export const dbEnabled = config.databaseUrl.length > 0;

let pool: Pool | null = null;
let ready = false;

/** Same SQL as server/schema.sql (kept inline so the server can self-migrate). */
const SCHEMA_SQL = `
create table if not exists jarvis_conversations (
  id uuid primary key,
  device_id text not null,
  title text not null default 'New conversation',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists jarvis_conversations_device_idx
  on jarvis_conversations (device_id, updated_at desc);

create table if not exists jarvis_messages (
  id bigserial primary key,
  conversation_id uuid not null references jarvis_conversations(id) on delete cascade,
  role text not null check (role in ('user', 'assistant')),
  content text not null,
  created_at timestamptz not null default now()
);
create index if not exists jarvis_messages_conv_idx
  on jarvis_messages (conversation_id, id);

alter table jarvis_conversations enable row level security;
alter table jarvis_messages enable row level security;
`;

function getPool(): Pool {
  if (!pool) {
    const needsSsl =
      /sslmode=require/i.test(config.databaseUrl) ||
      /supabase\.(co|com)/i.test(config.databaseUrl) ||
      /pooler\./i.test(config.databaseUrl);
    pool = new Pool({
      connectionString: config.databaseUrl,
      max: 5,
      idleTimeoutMillis: 30_000,
      connectionTimeoutMillis: 8_000,
      ssl: needsSsl ? { rejectUnauthorized: false } : undefined,
    });
    pool.on('error', (err) => console.error('[db] idle client error:', err.message));
  }
  return pool;
}

/** Creates tables if needed. Safe to call repeatedly. Never throws. */
export async function initDb(): Promise<boolean> {
  if (!dbEnabled) return false;
  try {
    await getPool().query(SCHEMA_SQL);
    ready = true;
    console.log('[db] connected and schema is ready');
  } catch (err) {
    ready = false;
    console.error('[db] could not initialise:', err instanceof Error ? err.message : err);
  }
  return ready;
}

/** Lightweight connectivity check used by /api/health. */
export async function dbPing(): Promise<boolean> {
  if (!dbEnabled) return false;
  try {
    await getPool().query('select 1');
    if (!ready) await initDb();
    return true;
  } catch {
    return false;
  }
}

export function dbReady(): boolean {
  return dbEnabled && ready;
}

/**
 * Stores one user/assistant exchange. The conversation is created on first use and is
 * bound to the device id, so one device can never write into another device's conversation.
 */
export async function saveExchange(params: {
  deviceId: string;
  conversationId: string;
  title: string;
  userText: string;
  assistantText: string;
}): Promise<void> {
  if (!dbReady()) return;
  const client = await getPool().connect();
  try {
    await client.query('begin');
    const upsert = await client.query(
      `insert into jarvis_conversations (id, device_id, title)
       values ($1, $2, $3)
       on conflict (id) do update set updated_at = now()
         where jarvis_conversations.device_id = excluded.device_id
       returning id`,
      [params.conversationId, params.deviceId, params.title.slice(0, 120)],
    );
    if (upsert.rowCount === 0) {
      await client.query('rollback');
      return; // conversation belongs to another device: ignore silently
    }
    await client.query(
      `insert into jarvis_messages (conversation_id, role, content) values ($1, 'user', $2), ($1, 'assistant', $3)`,
      [params.conversationId, params.userText, params.assistantText],
    );
    await client.query('commit');
  } catch (err) {
    await client.query('rollback').catch(() => undefined);
    throw err;
  } finally {
    client.release();
  }
}

interface SummaryRow {
  id: string;
  title: string;
  created_at: Date;
  updated_at: Date;
  message_count: string;
}

function toSummary(r: SummaryRow): ConversationSummary {
  return {
    id: r.id,
    title: r.title,
    createdAt: r.created_at.toISOString(),
    updatedAt: r.updated_at.toISOString(),
    messageCount: Number(r.message_count),
  };
}

export async function listConversations(deviceId: string): Promise<ConversationSummary[]> {
  if (!dbReady()) return [];
  const { rows } = await getPool().query<SummaryRow>(
    `select c.id, c.title, c.created_at, c.updated_at, count(m.id) as message_count
       from jarvis_conversations c
       left join jarvis_messages m on m.conversation_id = c.id
      where c.device_id = $1
      group by c.id
      order by c.updated_at desc
      limit 100`,
    [deviceId],
  );
  return rows.map(toSummary);
}

interface MessageRow {
  conversation_id: string;
  role: 'user' | 'assistant';
  content: string;
  created_at: Date;
}

async function messagesFor(conversationIds: string[]): Promise<Map<string, StoredMessage[]>> {
  const map = new Map<string, StoredMessage[]>();
  if (conversationIds.length === 0) return map;
  const { rows } = await getPool().query<MessageRow>(
    `select conversation_id, role, content, created_at
       from jarvis_messages
      where conversation_id = any($1::uuid[])
      order by id asc`,
    [conversationIds],
  );
  for (const r of rows) {
    const list = map.get(r.conversation_id) ?? [];
    list.push({ role: r.role, content: r.content, createdAt: r.created_at.toISOString() });
    map.set(r.conversation_id, list);
  }
  return map;
}

export async function getConversation(deviceId: string, id: string): Promise<ConversationFull | null> {
  if (!dbReady()) return null;
  const { rows } = await getPool().query<SummaryRow>(
    `select c.id, c.title, c.created_at, c.updated_at, count(m.id) as message_count
       from jarvis_conversations c
       left join jarvis_messages m on m.conversation_id = c.id
      where c.device_id = $1 and c.id = $2
      group by c.id`,
    [deviceId, id],
  );
  const row = rows[0];
  if (!row) return null;
  const msgs = await messagesFor([id]);
  return { ...toSummary(row), messages: msgs.get(id) ?? [] };
}

export async function exportAll(deviceId: string): Promise<ConversationFull[]> {
  const list = await listConversations(deviceId);
  const msgs = await messagesFor(list.map((c) => c.id));
  return list.map((c) => ({ ...c, messages: msgs.get(c.id) ?? [] }));
}

export async function deleteConversation(deviceId: string, id: string): Promise<void> {
  if (!dbReady()) return;
  await getPool().query('delete from jarvis_conversations where device_id = $1 and id = $2', [deviceId, id]);
}

export async function deleteAll(deviceId: string): Promise<void> {
  if (!dbReady()) return;
  await getPool().query('delete from jarvis_conversations where device_id = $1', [deviceId]);
}
