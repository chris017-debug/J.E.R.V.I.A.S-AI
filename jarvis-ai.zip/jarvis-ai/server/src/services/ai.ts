import { aiConfigured, config } from '../config';

export type Lang = 'en' | 'sw';

export interface ChatTurn {
  role: 'user' | 'assistant';
  content: string;
}

export type AiErrorCode = 'unauthorized' | 'rate_limited' | 'timeout' | 'upstream' | 'network' | 'empty';

export class AiError extends Error {
  readonly code: AiErrorCode;
  readonly status: number;
  constructor(code: AiErrorCode, message: string, status = 502) {
    super(message);
    this.name = 'AiError';
    this.code = code;
    this.status = status;
  }
}

/** Friendly, user-facing error text in both supported languages. */
export function friendlyMessage(code: string, lang: Lang): string {
  const en: Record<string, string> = {
    unauthorized:
      'My AI core rejected its credentials. Please ask the administrator to check the server API key.',
    rate_limited: 'My AI core is receiving too many requests right now. Please try again in a moment.',
    timeout: 'The AI core took too long to respond. Please try again.',
    upstream: 'The AI service is temporarily unavailable. Please try again shortly.',
    network: 'I cannot reach the AI service at the moment. Please check the server connection.',
    empty: 'The AI core returned an empty response. Please rephrase and try again.',
    unauthorized_app: 'Access denied. Enter the correct access passcode in Settings.',
    bad_request: 'That request did not look right. Please try again.',
    too_many_requests: 'Too many requests. Please slow down for a moment.',
    internal: 'Something went wrong inside the server. Please try again.',
  };
  const sw: Record<string, string> = {
    unauthorized:
      'Kiini changu cha AI kimekataa funguo zake. Tafadhali mwambie msimamizi akague API key ya seva.',
    rate_limited: 'Kiini changu cha AI kinapokea maombi mengi sana sasa hivi. Jaribu tena baada ya muda mfupi.',
    timeout: 'Kiini cha AI kimechukua muda mrefu kujibu. Tafadhali jaribu tena.',
    upstream: 'Huduma ya AI haipatikani kwa muda. Tafadhali jaribu tena baadaye kidogo.',
    network: 'Siwezi kufikia huduma ya AI kwa sasa. Tafadhali angalia muunganisho wa seva.',
    empty: 'Kiini cha AI kimerudisha jibu tupu. Tafadhali jaribu kuuliza kwa namna nyingine.',
    unauthorized_app: 'Ufikiaji umekataliwa. Weka nenosiri sahihi la kufikia kwenye Mipangilio.',
    bad_request: 'Ombi hilo halikuwa sahihi. Tafadhali jaribu tena.',
    too_many_requests: 'Maombi ni mengi sana. Tafadhali punguza kasi kidogo.',
    internal: 'Kuna hitilafu ndani ya seva. Tafadhali jaribu tena.',
  };
  const table = lang === 'sw' ? sw : en;
  return table[code] ?? table.internal;
}

function systemPrompt(lang: Lang): string {
  const preferred = lang === 'sw' ? 'Swahili (Kiswahili)' : 'English';
  const now = new Date().toISOString();
  return [
    'You are J.A.R.V.I.S ("Just A Rather Very Intelligent System"), a calm, witty, highly capable personal AI assistant with a refined, slightly dry sense of humour.',
    `The user's interface language is ${preferred}. Always reply in the language the user writes in (English or Swahili). If the user mixes languages, reply in the language they used most. If unsure, use ${preferred}.`,
    'Your replies are often read aloud by a text-to-speech voice, so write natural spoken prose: short sentences, no emojis, no tables, no long lists. Use at most a few short bullet points, and only when truly needed.',
    'Be concise by default (usually 1-4 sentences) and give more detail only when asked. Be honest: if you do not know something or cannot do it, say so plainly.',
    'You cannot control the user\'s device, browse the web, or access private data unless the user provides it in the conversation.',
    `Current server time (UTC): ${now}.`,
  ].join('\n');
}

export interface AiResult {
  reply: string;
  model: string;
  demo: boolean;
}

function demoReply(lang: Lang): string {
  return lang === 'sw'
    ? 'Niko katika hali ya majaribio kwa sababu funguo ya AI haijawekwa kwenye seva. Weka AI_API_KEY kwenye faili la server/.env kisha uanzishe seva upya ili nijibu kwa akili kamili.'
    : 'I am running in demo mode because no AI key is configured on the server. Set AI_API_KEY in server/.env and restart the server so I can answer with my full intelligence.';
}

interface OpenAiChatResponse {
  choices?: Array<{ message?: { content?: string | null } }>;
}

export async function askAi(turns: ChatTurn[], lang: Lang): Promise<AiResult> {
  if (!aiConfigured()) {
    return { reply: demoReply(lang), model: 'demo', demo: true };
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), config.ai.timeoutMs);

  let res: Response;
  try {
    res = await fetch(`${config.ai.baseUrl}/chat/completions`, {
      method: 'POST',
      signal: controller.signal,
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${config.ai.apiKey}`,
      },
      body: JSON.stringify({
        model: config.ai.model,
        temperature: config.ai.temperature,
        max_tokens: config.ai.maxTokens,
        messages: [{ role: 'system', content: systemPrompt(lang) }, ...turns],
      }),
    });
  } catch (err) {
    const aborted = err instanceof Error && err.name === 'AbortError';
    throw aborted
      ? new AiError('timeout', 'AI request timed out', 504)
      : new AiError('network', 'Could not reach the AI provider', 502);
  } finally {
    clearTimeout(timer);
  }

  if (!res.ok) {
    // Log provider status only; never log headers or keys.
    console.error(`[ai] provider responded with HTTP ${res.status}`);
    if (res.status === 401 || res.status === 403) throw new AiError('unauthorized', 'Provider rejected credentials', 502);
    if (res.status === 429) throw new AiError('rate_limited', 'Provider rate limit', 429);
    throw new AiError('upstream', `Provider error ${res.status}`, 502);
  }

  let data: OpenAiChatResponse;
  try {
    data = (await res.json()) as OpenAiChatResponse;
  } catch {
    throw new AiError('upstream', 'Provider returned invalid JSON', 502);
  }

  const reply = data.choices?.[0]?.message?.content?.trim();
  if (!reply) throw new AiError('empty', 'Provider returned an empty message', 502);
  return { reply, model: config.ai.model, demo: false };
}
