# J.A.R.V.I.S — Msaidizi wa AI wa Kisasa (Kiingereza + Kiswahili)

**JUST A RATHER VERY INTELLIGENT SYSTEM** — dashibodi ya kisasa ya rangi nyeusi na bluu-cyan inayong'aa, yenye reactor kubwa ya duara, pete zinazozunguka, mawimbi ya sauti, chembechembe, saa ya moja kwa moja, na msaidizi wa AI anayeongea na kusikiliza. Inafanya kazi kwenye **simu ya Android, tablet na kompyuta**.

Michoro yote ni ya asili (CSS/Canvas/SVG). Hakuna video wala picha zilizonakiliwa kutoka kwenye filamu.

---

## 1. Kilichomo

| Kipengele | Maelezo |
|---|---|
| Dashibodi | Reactor inayozunguka, pete, scan, waveform, particles, saa/tarehe, hali ya mfumo, viashiria vya AI |
| Chat | Andika swali, pata jibu la AI, markdown, nakili, jaribu tena, bubble ya kosa la kirafiki |
| Sauti | Kitufe cha maikrofoni (Speech Recognition), JARVIS anasoma jibu (Speech Synthesis), hali ya **hands-free** |
| Hali za AI | Idle, **Listening**, **Thinking**, **Speaking** (rangi na kasi ya reactor hubadilika) |
| Command Center | Chat, Voice Assistant, System Status, Settings, History: vyote vinafanya kazi |
| Lugha | Kiingereza na Kiswahili (UI, majibu ya AI, sauti ya kusoma, kutambua sauti) |
| Amri za ndani | "saa ngapi", "tarehe ya leo", "fungua mipangilio", "speak swahili", "futa mazungumzo": hazipigi AI |
| Historia | Inahifadhiwa kwenye kivinjari (localStorage) na, ukiweka `DATABASE_URL`, pia kwenye Supabase/PostgreSQL |
| Usalama | API key ipo **kwenye seva pekee**; rate limit; helmet; passcode ya hiari; validation ya zod |
| PWA | Inasakinishwa kwenye simu/kompyuta kama app, inafunguka haraka na hata offline (kioo cha app) |

## 2. Muundo wa mradi

```
jarvis-ai/
├── package.json              # amri za mizizi (dev, build, start)
├── render.yaml               # deploy ya Render (bure)
├── client/                   # React + TypeScript + Tailwind + Framer Motion
│   ├── public/               # manifest, service worker, icons za PWA
│   └── src/
│       ├── App.tsx           # mpangilio mkuu (responsive)
│       ├── store.ts          # hali ya app, chat, sauti, historia (zustand)
│       ├── components/       # Reactor, Particles, Waveform, ChatPanel, VoicePanel, ...
│       └── lib/              # api, speech, i18n (EN/SW), intents, lang
└── server/                   # Node.js + Express + TypeScript
    ├── schema.sql            # jedwali la database (hiari: seva inajitengenezea)
    ├── .env.example          # mfano wa mipangilio
    └── src/
        ├── index.ts          # seva, usalama, inahudumia client iliyojengwa
        ├── routes/           # chat.ts, history.ts, health.ts
        ├── services/         # ai.ts (Groq/OpenAI-compatible), db.ts (Postgres)
        └── middleware/auth.ts
```

## 3. Mahitaji

- **Node.js 20 au zaidi** (https://nodejs.org, chagua LTS)
- Akaunti ya **Groq** kwa AI (bure): https://console.groq.com/keys
- (Hiari) Akaunti ya **Supabase** kwa historia ya wingu: https://supabase.com

## 4. Kuendesha kwenye kompyuta (hatua kwa hatua)

```bash
# 1) Ingia kwenye folda ya mradi
cd jarvis-ai

# 2) Weka vifurushi vyote (mizizi + server + client)
npm install
npm run install:all

# 3) Tengeneza faili la siri la seva
cp server/.env.example server/.env        # Windows: copy server\.env.example server\.env

# 4) Fungua server/.env kisha weka ufunguo wako:
#    AI_API_KEY=gsk_...

# 5) Anzisha seva na dashibodi pamoja
npm run dev
```

Fungua **http://localhost:5173**. Bonyeza kitufe cha kuanza, kisha andika au bonyeza reactor/maikrofoni ili kuongea.

> Bila `AI_API_KEY`, JARVIS anajibu kwa **demo mode** na kukuambia aongeze ufunguo. Vitufe vingine vyote bado vinafanya kazi.

Angalia kama kila kitu kiko sawa: fungua http://localhost:8787/api/health (inaonyesha kama AI na database zimeunganishwa).

### Toleo la production kwenye kompyuta (seva moja)

```bash
npm run build      # jenga client kisha server
npm start          # http://localhost:8787 (seva inahudumia app nzima)
```

## 5. Funguo za siri na usalama

- Funguo zinakaa **tu** kwenye `server/.env` (au kwenye Environment Variables za host). Faili hilo liko kwenye `.gitignore`: **usilipandishe GitHub**.
- Frontend haina funguo yoyote. Kila kitu cha AI kinapita `POST /api/chat` ya seva.
- **Funguo ulizobandika kwenye mazungumzo ya Claude zimeonekana wazi. Zibadilishe:** tengeneza funguo mpya kwenye Groq (na kwenye huduma yako ya sauti), kisha futa za zamani.
- Ukiweka app mtandaoni, weka `APP_PASSCODE` (nenosiri lolote). Kisha uliweke kwenye **Settings → Access passcode** ndani ya app. Hii inazuia watu wengine kutumia credits zako.
- `RATE_LIMIT_PER_MIN` inapunguza maombi kwa kila IP (chaguo-msingi 40).

### Kuhusu ufunguo wa "sound model"

Ufunguo wa pili uliotoa (`612b…`) uliwekwa kama `SPEECH_API_KEY` kwenye `server/.env`, lakini **bado hautumiki** kwa sababu huduma yake haikutajwa. Sauti sasa inatumia Speech Recognition na Speech Synthesis za kivinjari (bila malipo, bila funguo). Ukinijulisha huduma ni ipi (mfano AssemblyAI, Deepgram, ElevenLabs), naweza kuunganisha kupitia seva vilevile.

## 6. Kuijaribu kwenye simu ukiwa nyumbani (Wi-Fi moja)

1. Simu na kompyuta ziwe kwenye Wi-Fi moja.
2. Kompyuta: `npm run dev`. Tafuta IP ya kompyuta (`ipconfig` Windows, `ifconfig`/`ip a` Mac/Linux), mfano `192.168.1.20`.
3. Simu: fungua Chrome kisha **http://192.168.1.20:5173**.

⚠️ **Maikrofoni haifanyi kazi kwenye `http://` ya IP.** Kivinjari kinaruhusu maikrofoni kwenye **HTTPS** au `localhost` tu. Kuandika, kusomewa majibu na kila kitu kingine kinafanya kazi, lakini ili kutumia sauti ya kuingiza kwenye simu, weka app mtandaoni (hatua ya 7) ili upate HTTPS.

## 7. Kuiweka mtandaoni (HTTPS) kwa Render, bure

1. Weka mradi kwenye **GitHub** (mradi mpya, `git init`, `git add .`, `git commit`, `git push`). Hakikisha `server/.env` **haipo** kwenye commit.
2. Nenda https://render.com, **New → Blueprint**, chagua repo yako. Render itasoma `render.yaml`.
3. Kwenye dashibodi ya Render weka:
   - `AI_API_KEY` = ufunguo mpya wa Groq
   - `APP_PASSCODE` = nenosiri lako
   - `DATABASE_URL` = (hiari, angalia hatua ya 8)
4. Subiri build ikamilike. Utapata anwani kama `https://jarvis-ai.onrender.com`.
5. Fungua anwani hiyo, ingia **Settings**, weka passcode.

> Mpango wa bure wa Render "hulala" baada ya dakika 15 bila matumizi, hivyo ombi la kwanza linaweza kuchukua sekunde 30-50. Mbadala: Railway, Fly.io, au VPS yoyote yenye Node 20.

## 8. Historia ya wingu na Supabase (hiari)

1. Supabase: **New project** kisha **Project Settings → Database → Connection string → URI** (tumia ya "Session pooler" kama ya moja kwa moja haifanyi kazi).
2. Badilisha `[YOUR-PASSWORD]` na nenosiri la database, kisha ibandike kwenye `DATABASE_URL`.
3. Anzisha seva upya. Itatengeneza majedwali yenyewe (`schema.sql` ni ya hiari). `/api/health` itaonyesha `db.connected: true`.
4. Kila kifaa kina kitambulisho chake cha siri kilichowekwa kwenye **Settings**. Ukitaka historia ile ile kwenye simu na kompyuta, nakili kitambulisho kutoka kimoja na ukiweke kwenye kingine, kisha kwenye paneli ya **History** bonyeza **Restore from cloud**.

Bila `DATABASE_URL`, historia inabaki kwenye kivinjari tu, na vitufe vya History (tafuta, futa, hamisha) vinafanya kazi vilevile.

## 9. Kuifanya app kwenye simu na kompyuta

Njia rahisi na bora ni **PWA** (inahitaji HTTPS, yaani baada ya hatua ya 7):

**Android (Chrome / Samsung Internet)**
1. Fungua anwani ya app kwenye Chrome.
2. Menyu ya nukta tatu **⋮ → Install app** (au "Add to Home screen").
3. Ikoni ya JARVIS itaonekana kwenye skrini ya nyumbani na itafunguka skrini nzima, kama app ya kawaida.
4. Ukiona kitufe cha **Install** ndani ya Settings, unaweza kukitumia pia.

**Kompyuta (Chrome / Edge)**
1. Fungua anwani ya app.
2. Bonyeza ikoni ya kusakinisha kwenye upau wa anwani (kompyuta ndogo yenye mshale), au menyu **⋮ → Cast, save and share → Install page as app**.
3. App itafunguka kwenye dirisha lake na kuwa na ikoni kwenye desktop/Start menu.

**iPhone/iPad (Safari)**: **Share → Add to Home Screen**. Utambuzi wa sauti hautegemewi sana kwenye iOS.

**APK halisi ya Android (hiari)**: ukitaka faili la `.apk`/`.aab` kwa ajili ya Play Store, tumia **PWABuilder** (https://www.pwabuilder.com): bandika anwani ya app yako ya HTTPS, chagua **Android**, kisha upakue kifurushi. Inatumia manifest ya `client/public/manifest.webmanifest` iliyopo tayari.

## 10. Sauti: Kiingereza na Kiswahili

- **Kusikiliza (maikrofoni):** Chrome/Edge/Samsung Internet. Kiswahili kinatumia `sw-TZ`; Kiingereza `en-US`. Inahitaji intaneti.
- **Kuongea:** Kivinjari kinatumia sauti zilizosakinishwa kwenye kifaa. Kiingereza huchagua sauti ya kiume ya Uingereza kama ipo. Kwa Kiswahili, kwenye Android sakinisha **Google Speech Services** na pakua data ya sauti ya Kiswahili (*Settings → System → Languages & input → Text-to-speech → Google → Install voice data*). Ukichagua sauti nyingine, nenda **Settings → Voice**.
- Unaweza kubadili lugha kwa kusema "speak swahili" / "ongea Kiingereza".
- **Hands-free:** kwenye paneli ya Voice, JARVIS anasikiliza, anajibu kwa sauti, kisha anasikiliza tena, hadi usimamishe (Escape au kitufe cha Stop).

## 11. API ya seva

| Njia | Maelezo |
|---|---|
| `GET /api/health` | Hali ya seva, AI na database (haina siri) |
| `POST /api/chat` | `{ messages, lang, conversationId, title }` → `{ reply, model, demo }` |
| `GET /api/history` | Orodha ya mazungumzo ya kifaa |
| `GET /api/history/export` | Mazungumzo yote kwa ujumbe |
| `GET /api/history/:id` | Mazungumzo moja |
| `DELETE /api/history/:id` | Futa mazungumzo moja |
| `DELETE /api/history` | Futa yote |

Maombi ya `/api/chat` na `/api/history` yanahitaji header `x-device-id` na (kama `APP_PASSCODE` imewekwa) `x-jarvis-passcode`. Makosa yote yanarudi kama `{ "error": { "code", "message" } }` kwa lugha ya mtumiaji.

Kutumia mtoa huduma mwingine wa AI (OpenAI, OpenRouter, Together): badilisha `AI_BASE_URL`, `AI_MODEL` na `AI_API_KEY` kwenye `.env`. Hakuna code ya kubadilisha.

## 12. Utatuzi wa matatizo

| Tatizo | Suluhisho |
|---|---|
| Jibu linasema "demo mode" | `AI_API_KEY` haijawekwa au seva haikuanzishwa upya baada ya kuhariri `.env` |
| "My AI core rejected its credentials" | Ufunguo si sahihi au umefutwa; tengeneza mpya |
| Maikrofoni haifanyi kazi kwenye simu | Tumia HTTPS (hatua ya 7) na ruhusu maikrofoni kwenye kivinjari |
| Sauti haisomi kwa Kiswahili | Sakinisha data ya sauti ya Kiswahili (hatua ya 10) |
| Kiashiria cha Core kinasema offline | Seva haifanyi kazi; angalia terminal ya `npm run dev` |
| "Access denied" | `APP_PASSCODE` imewekwa; liingize kwenye Settings |
| Database inaonyesha error | Tumia connection string ya "pooler" ya Supabase; angalia nenosiri |
| App ya zamani inaonekana baada ya update | Funga na ufungue app mara mbili (service worker inajisasisha) |

## 13. Kilichojaribiwa kabla ya kukupa

Mazingira niliyojengea hayakuweza kupakua vifurushi vya npm wala kufikia Groq, kwa hiyo **`npm install`, `npm run build` na jaribio la Groq halisi bado hujafanywa**. Kilichojaribiwa:

- Mantiki ya AI ya seva dhidi ya seva bandia ya OpenAI/Groq: jibu la kawaida, 401, 429, 500, jibu tupu, timeout na demo mode (9 majaribio, yote yamepita).
- Mantiki ya client: amri za ndani, utambuzi wa Kiswahili/Kiingereza, usafishaji wa maandishi ya sauti, usawa wa tafsiri (14 majaribio, yote yamepita).
- Aina za TypeScript: hakuna makosa halisi (isipokuwa yale ya vifurushi visivyopakuliwa).
- UI kwenye Chromium (simu 390×844 na kompyuta 1440×900) kwa vifurushi bandia vidogo: boot, kutuma ujumbe, jibu, bubble ya kosa, vitufe vyote vitano vya command center, kubadili lugha, na hakuna kuanguka kwa runtime. Hii haikuhakiki mwonekano wa Tailwind/Framer Motion kwa sababu hazikupatikana.

Kwa hiyo hatua ya kwanza kwenye kompyuta yako ni `npm run install:all && npm run typecheck && npm run build`. Ukipata kosa lolote, nitumie maandishi yake na nitalirekebisha.
